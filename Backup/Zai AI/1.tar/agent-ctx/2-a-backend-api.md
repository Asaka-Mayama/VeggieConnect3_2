# Task 2-a — Backend API Layer (VeggieConnect port to Next.js + Prisma/SQLite)

Agent: backend-api
Date: 2026-11-07

## What was built

Complete port of every `/api/*` endpoint from the original Express+MySQL server
(`/tmp/VeggieConnect3_1/server.ts`, 2525 lines) to Next.js 16 App Router route
handlers backed by Prisma/SQLite. Payload shapes, status codes, error messages,
ordering rules, and business logic mirror the original line-for-line.

## Files created

- `src/app/api/_lib/rows.ts` — shared row→app-object converters
  (`userFromRow`, `productFromRow`, `orderFromRow`, `jobFromRow`,
  `messageFromRow`, `normId`, `JOB_STATUSES`). Data JSON column is preferred;
  plain-column reconstruction only for unparseable rows (mirrors
  `rowToOrder`/`rowToJob`/`rowToMessage`).
- `src/veggieconnect/server/daBulletin.ts` — verbatim copy of
  `INITIAL_DA_BULLETIN` (24 items), module-level `daPricesCache` +
  `daPricesLastSynced`, and `syncLatestDAPrices()` (3.5s AbortController fetch
  with fallback mode `verified_amas_bulletin`).
- `src/app/api/health/route.ts` — GET (static XAMPP-compatible status payload).
- `src/app/api/auth/signup/route.ts` — POST (dup name/phone/email checks with
  original wording, hashed password persisted to `passwordHash` column only,
  `data` JSON sans password, 201 `{success, message, user}`).
- `src/app/api/auth/login/route.ts` — POST (admin special-case with accepted
  password list + persisted hash verify + persisted profile overrides; regular
  lookup by email/phone/name; 404/400/401/403 flows identical; `safeUser`).
- `src/app/api/users/route.ts` — GET (parsed `data` of all non-transporter users).
- `src/app/api/users/[id]/route.ts` — PUT (field-by-field merge semantics incl.
  VALID_ROLES gate and lat/lng parseFloat-or-undefined; create-from-body when
  row missing) + DELETE (cascade product deletion by farmerId / farmName /
  farmerName, case-insensitive).
- `src/app/api/supermarket/route.ts` — GET/PUT (singleton; lat/lng validation
  400; savedAt BigInt→Number for JSON safety; optional merge semantics).
- `src/app/api/products/route.ts` — GET (newest first) + POST (full default
  build per lines 1184-1215; supermarket dedup by id OR normalized name with
  paren-strip norm; stock sum + boughtQuantity max; returns 201 newProduct).
- `src/app/api/products/[id]/route.ts` — PUT (Object.assign merge, create when
  missing, column refresh) + DELETE (`{success, message:'Product deleted'}`).
- `src/app/api/reset-all/route.ts` — POST (403 unless `VITE_ENABLE_DEMO_RESET=true`;
  wipes products/orders/jobs/messages, keeps admin@gmail.com).
- `src/app/api/orders/route.ts` — GET (createdAtMs DESC nulls-last, createdAt
  DESC, rowToOrder-style numeric normalization) + POST (write-through; stock
  deduction with `sold_out` flip when no sellerStoreName; auto-create
  direct-delivery transport job per lines 1472-1485; 201 order).
- `src/app/api/orders/[id]/route.ts` — PUT (create-when-missing; cancellation
  restock by produceId OR normalized name; `sold_out`→`bought_and_stocked`;
  transport-job cancellation fan-out with '#'-stripped id matching + farmName/
  buyerName fallback; merge + persist).
- `src/app/api/transport-jobs/route.ts` — GET (cancelled-order consistency
  enforcement, persisting changes) + POST (upsert by id, 201 job).
- `src/app/api/transport-jobs/[id]/route.ts` — PUT (404 when missing; optional
  truthy fields; order sync: transporter copy, accepted/picked_up/in_transit→
  order in_transit, delivered→completed).
- `src/app/api/messages/route.ts` — GET (oldest first) + POST (id fallback
  `msg-${Date.now()}`; upsert; createdAtMs from parsed timestamp or now; kept
  on replace like the original ON DUPLICATE KEY UPDATE).
- `src/app/api/messages/read-all/route.ts` — PUT (400 'Missing userId';
  recipientId/farmerId/role-based farmer match).
- `src/app/api/messages/mark-read/route.ts` — POST (messageIds OR conversation
  match incl. `admin-main`+senderRole admin rule).
- `src/app/api/da-prices/route.ts` — GET (category/search filters, metadata
  with bulletinDate/lastSynced/marketCenter/dataSource/agency/inflationNote).
- `src/app/api/da-prices/sync/route.ts` — POST (sync + response envelope).
- `src/app/api/xampp/export/route.ts` — GET (verbatim SQL dump template,
  `application/sql`, attachment `veggie_connect3.sql`).

## Verification performed

Runtime-tested every endpoint via curl against the auto-running dev server:
signup dup name/phone/email messages, admin + user login (wrong password,
missing account, missing password), users list/PUT (bio+lat merge)/DELETE
cascade, supermarket PUT/GET (savedAt number, 400 on bad coords), products
POST defaults, SM dedup merge (stock 5+9=14, boughtQuantity max, response
keeps newProduct with merged id), product PUT/DELETE, order POST stock
deduction 10→6 + job auto-create (itemsSummary/earnings), job accept → order
in_transit + transporter copy, order cancel → restock 6→10 + job cancelled
with cancelReason/cancelledAt, job GET consistency re-cancel, jobs POST
upsert, messages POST/GET/mark-read/read-all, da-prices filters + sync
(updatedDate refreshed, 24 commodities), xampp export headers+content,
reset-all 403. Test data cleaned afterwards (DB back to admin + default hub).
`bunx tsc --noEmit` passes for all files in my scope.

## Deviations / notes for next agents

1. **DB-required ids**: order/job POST bodies without an `id` get one
   generated (`ord-…` / `TJ-…`) before persistence; the response includes the
   resolved id (original returned the raw body). Frontend always sends ids, so
   no practical difference — persistence simply requires an id.
2. **Orders/jobs POST use Prisma upsert** (mirrors the original's
   `INSERT … ON DUPLICATE KEY UPDATE` write-through) instead of blind create,
   so repeat ids can't 500.
3. **`cache: 'no-store'`** added to the DA portal fetch (Next-specific; keeps
   runtime behavior identical to the original live fetch).
4. **Email fallback on users PUT create-path** (`{id}@veggieconnect.ph`,
   uniquified) because the Prisma `User.email` column is required+unique; the
   original in-memory push had no such constraint.
5. **Login lookup includes transporter rows** so the retired-account 403 path
   ('This account type is no longer available.') stays reachable, per spec.
6. **BigInt columns** (`createdAtMs`, `savedAt`) are converted with
   `BigInt()`/`Number()` at the Prisma boundary; JSON payloads always carry
   plain numbers.
7. SQLite default NULL ordering gives exactly the original semantics without
   Prisma's unsupported `nulls` option: DESC → nulls last (orders/jobs),
   ASC → nulls first (messages).
8. Work record lives at `/home/z/my-project/agent-ctx/` (filesystem-root
   `/agent-ctx` is not writable by this user).
