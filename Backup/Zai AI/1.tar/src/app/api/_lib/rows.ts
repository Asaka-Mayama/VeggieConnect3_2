// ---------------------------------------------------------------------------
// Shared row -> app-object converters for the VeggieConnect API routes.
//
// Mirrors rowToOrder / rowToJob / rowToMessage / product hydration inside the
// original Express server (server.ts): the canonical JSON `data` column is
// preferred, and plain-column reconstruction is only a fallback for rows whose
// `data` payload is missing or unparseable.
// ---------------------------------------------------------------------------

import { asNum, parseRecord } from '@/veggieconnect/server/helpers';

export const JOB_STATUSES = ['available', 'accepted', 'picked_up', 'in_transit', 'delivered', 'cancelled'];

export function userFromRow(row: any): any {
  return (
    parseRecord(row?.data) || {
      id: row.id,
      name: row.name,
      email: row.email,
      phone: row.phone,
      role: row.role,
    }
  );
}

export function productFromRow(row: any): any {
  return (
    parseRecord(row?.data) || {
      id: row.id,
      farmerId: row.farmerId || 'farmer-1',
      farmerName: row.farmerName,
      farmName: row.farmName,
      name: row.name,
      sellerStatus: row.sellerStatus || 'submitted',
      sellerStoreName: row.sellerStoreName || undefined,
    }
  );
}

export function orderFromRow(row: any): any {
  const o =
    parseRecord(row?.data) || {
      id: row.id,
      buyerId: row.buyerId || undefined,
      farmerId: row.farmerId || undefined,
      farmName: row.farmName || undefined,
      transportJobId: row.transportJobId || undefined,
      items: [],
      status: row.status,
    };
  if (o) {
    // Same numeric guarantees the original rowToOrder applied after hydration.
    o.totalAmount = asNum(o.totalAmount ?? o.subtotal, 0);
    o.subtotal = asNum(o.subtotal ?? o.totalAmount, 0);
    o.deliveryFee = asNum(o.deliveryFee, 0);
    if (!Array.isArray(o.items)) o.items = [];
  }
  return o;
}

export function jobFromRow(row: any): any {
  return (
    parseRecord(row?.data) || {
      id: row.id,
      orderId: row.orderId || undefined,
      status: row.status || 'available',
    }
  );
}

export function messageFromRow(row: any): any {
  return (
    parseRecord(row?.data) || {
      id: row.id,
      senderId: row.senderId || undefined,
      recipientId: row.recipientId || undefined,
      isRead: Boolean(row.isRead),
    }
  );
}

/** Normalizes an id exactly like the original server did for job/order matching. */
export const normId = (v: any): string => String(v || '').replace('#', '').trim().toLowerCase();
