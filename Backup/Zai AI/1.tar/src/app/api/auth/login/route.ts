// 3. Authentication: Login — port of POST /api/auth/login
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import {
  ADMIN_PASSWORD,
  ensureSeed,
  isRetiredAccount,
  normalizePhone,
  passwordsMatch,
  safeUser,
  toOptionalNumber,
  verifyPassword,
} from '@/veggieconnect/server/helpers';
import { userFromRow } from '@/app/api/_lib/rows';

export async function POST(req: NextRequest) {
  try {
    await ensureSeed();
    const body: any = await req.json().catch(() => ({}));
    const { email, phone, password } = body;
    const identifier = (email || phone || '').toLowerCase().trim();
    if (!identifier) {
      return NextResponse.json({ error: 'Mobile Number or Email is required' }, { status: 400 });
    }

    // Special Check: System Administrator login
    if (identifier === 'admin@gmail.com' || identifier === 'admin' || identifier === 'admin desk') {
      const adminRows = await db.user.findMany({
        where: { OR: [{ id: 'admin-main' }, { role: 'admin' }] },
      });
      const persistedRow = adminRows.find(
        (u) =>
          u &&
          (u.id === 'admin-main' ||
            (u.role === 'admin' && u.email && u.email.toLowerCase() === 'admin@gmail.com'))
      );
      const persistedAdmin = persistedRow ? userFromRow(persistedRow) : null;

      const acceptedPasswords = [ADMIN_PASSWORD, 'admin123', 'admin', 'admin1234', 'password'].filter(Boolean);
      const isDefaultMatch = Boolean(password && acceptedPasswords.some((p) => passwordsMatch(password, p)));
      const isCustomMatch = Boolean(
        password && persistedRow?.passwordHash && verifyPassword(password, persistedRow.passwordHash)
      );

      if (!isDefaultMatch && !isCustomMatch) {
        return NextResponse.json({ error: 'incorrect password or username' }, { status: 401 });
      }
      const defaultAdmin = {
        id: 'admin-main',
        name: 'VeggieConnect Admin Desk',
        email: 'admin@gmail.com',
        phone: '+63 900 000 0000',
        role: 'admin',
        location: 'Rizal Boulevard & Port Area, Dumaguete City Proper, Negros Oriental',
        latitude: 9.308,
        longitude: 123.3105,
        verified: true,
        status: 'active',
        avatar: '',
      };
      // Return the persisted record so the signed-in session (and every farmer
      // live-route map resolving the admin through the shared registry) never
      // snaps back to the hard-coded default coordinates after a re-login.
      const adminUser = {
        ...defaultAdmin,
        ...(persistedAdmin
          ? {
              name: persistedAdmin.name || defaultAdmin.name,
              phone: persistedAdmin.phone || defaultAdmin.phone,
              location: persistedAdmin.location || defaultAdmin.location,
              latitude: toOptionalNumber(persistedAdmin.latitude) ?? defaultAdmin.latitude,
              longitude: toOptionalNumber(persistedAdmin.longitude) ?? defaultAdmin.longitude,
              avatar: persistedAdmin.avatar || defaultAdmin.avatar,
            }
          : {}),
      };
      return NextResponse.json({
        success: true,
        user: adminUser,
      });
    }

    const normPhone = normalizePhone(identifier);

    // Mirror the original lookup: match by email OR phone (with/without spaces,
    // or normalized) OR name, all lowercased / compared case-insensitively.
    const rows = await db.user.findMany();
    const row = rows.find((u) => {
      const o = userFromRow(u);
      return (
        (o.email && String(o.email).toLowerCase() === identifier) ||
        (o.phone &&
          (String(o.phone).replace(/\s+/g, '') === identifier.replace(/\s+/g, '') ||
            (normPhone && normalizePhone(o.phone) === normPhone))) ||
        (o.name && String(o.name).toLowerCase() === identifier)
      );
    });

    if (!row) {
      return NextResponse.json(
        { error: 'No registered account found with this Mobile Number or Email.' },
        { status: 404 }
      );
    }

    // The `data` profile JSON is the user as the app sees it; the password hash
    // lives only on the column.
    const user: any = { ...userFromRow(row), passwordHash: row.passwordHash };

    // Password verification: a password is REQUIRED, and the account must have one.
    if (!password) {
      return NextResponse.json({ error: 'Password is required.' }, { status: 400 });
    }
    if (!user.passwordHash || !verifyPassword(password, user.passwordHash)) {
      return NextResponse.json({ error: 'Incorrect password. Please try again.' }, { status: 401 });
    }

    // The transporter role no longer exists (the admin handles deliveries)
    if (isRetiredAccount(user)) {
      return NextResponse.json({ error: 'This account type is no longer available.' }, { status: 403 });
    }

    // Account Suspension Check
    if (user.status === 'suspended') {
      return NextResponse.json(
        {
          error: 'This account has been suspended by the administrator.',
          status: 'suspended',
        },
        { status: 403 }
      );
    }

    return NextResponse.json({
      success: true,
      user: safeUser(user),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
