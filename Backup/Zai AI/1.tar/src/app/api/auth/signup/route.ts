// 2. Authentication: Sign Up (Farmer or Buyer) — port of POST /api/auth/signup
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { ensureSeed, hashPassword, normalizePhone } from '@/veggieconnect/server/helpers';

export async function POST(req: NextRequest) {
  try {
    await ensureSeed();
    const body: any = await req.json().catch(() => ({}));
    const { name, email, password, phone, role, location, farmName } = body;

    if (!name || !role) {
      return NextResponse.json({ error: 'Name and role are required' }, { status: 400 });
    }
    // Only buyers and farmers can sign up. (Admin is configured in .env; nobody can self-register as admin.)
    if (role !== 'buyer' && role !== 'farmer') {
      return NextResponse.json({ error: 'Role must be buyer or farmer.' }, { status: 400 });
    }

    const trimmedName = String(name).trim();
    const normName = trimmedName.toLowerCase();
    const rawEmail = (email || '').trim();
    const normEmail = rawEmail.toLowerCase();
    const rawPhone = (phone || '').trim();
    const normPhone = normalizePhone(rawPhone);

    // Duplicate checks against the database (the original checked its
    // in-memory store then MySQL; both collapse onto the single SQLite store).
    const existingUsers = await db.user.findMany();

    // Duplicate Name check
    const dupName = existingUsers.find((u) => u.name && u.name.trim().toLowerCase() === normName);
    if (dupName) {
      return NextResponse.json(
        {
          error: `An account with the name "${trimmedName}" is already registered. Please choose a unique full name.`,
        },
        { status: 400 }
      );
    }

    // Duplicate Phone check
    if (normPhone) {
      const dupPhone = existingUsers.find((u) => u.phone && normalizePhone(u.phone) === normPhone);
      if (dupPhone) {
        return NextResponse.json(
          {
            error: `An account with the phone number "${rawPhone}" is already registered in the system.`,
          },
          { status: 400 }
        );
      }
    }

    // Duplicate Email check
    if (normEmail) {
      const dupEmail = existingUsers.find((u) => u.email && u.email.trim().toLowerCase() === normEmail);
      if (dupEmail) {
        return NextResponse.json(
          {
            error: `An account with the email "${rawEmail}" is already registered.`,
          },
          { status: 400 }
        );
      }
    }

    // Securely hash password
    const hashedPassword = hashPassword(password || 'farmer1234');

    const newUser: any = {
      id: `user-${Date.now()}`,
      name: trimmedName,
      email: rawEmail || `${trimmedName.toLowerCase().replace(/\s+/g, '')}@veggieconnect.ph`,
      phone: rawPhone || '+63 917 000 0000',
      role,
      location: location || 'Dumaguete City, Negros Oriental',
      latitude:
        body.latitude !== undefined && !isNaN(parseFloat(body.latitude)) ? parseFloat(body.latitude) : undefined,
      longitude:
        body.longitude !== undefined && !isNaN(parseFloat(body.longitude)) ? parseFloat(body.longitude) : undefined,
      farmName: role === 'farmer' ? farmName || `${trimmedName}'s Farm` : undefined,
      avatar: body.avatar || '',
      status: 'active',
      verified: true,
    };

    // Persist columns + the canonical `data` profile JSON (never the password).
    await db.user.create({
      data: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        phone: newUser.phone,
        role: newUser.role,
        passwordHash: hashedPassword,
        data: JSON.stringify(newUser),
      },
    });

    const userResponse = { ...newUser };
    delete userResponse.password_hash;

    return NextResponse.json(
      {
        success: true,
        message: `Account created successfully as ${role}!`,
        user: userResponse,
      },
      { status: 201 }
    );
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
