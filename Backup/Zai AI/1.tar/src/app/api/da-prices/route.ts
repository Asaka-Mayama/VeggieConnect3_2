// 11a. Get DA AMAS Daily Price Watch Bulletin — port of GET /api/da-prices
import { NextRequest, NextResponse } from 'next/server';
import { daPricesCache, daPricesLastSynced } from '@/veggieconnect/server/daBulletin';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get('category') || '';
    const search = searchParams.get('search') || '';
    const market = searchParams.get('market') || '';

    let filtered = [...daPricesCache];

    if (category && category !== 'All') {
      filtered = filtered.filter((i) => i.category.toLowerCase() === String(category).toLowerCase());
    }

    if (search) {
      const q = String(search).toLowerCase();
      filtered = filtered.filter(
        (i) =>
          i.commodity.toLowerCase().includes(q) ||
          (i.localName && i.localName.toLowerCase().includes(q)) ||
          (i.variety && i.variety.toLowerCase().includes(q))
      );
    }

    return NextResponse.json({
      status: 'ok',
      metadata: {
        bulletinDate: new Date().toLocaleDateString('en-US', {
          month: 'long',
          day: 'numeric',
          year: 'numeric',
        }),
        lastSynced: `Today at ${daPricesLastSynced.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
        })} (DA AMAS Price Monitoring)`,
        marketCenter: market ? String(market) : 'Dumaguete City Public Market & Negros Oriental (Region VII)',
        dataSource: 'Department of Agriculture - Agribusiness and Marketing Assistance Service (DA-AMAS)',
        agency: 'Republic of the Philippines Department of Agriculture',
        totalCommodities: filtered.length,
        inflationNote: 'Farm-gate to wet market retail benchmark synced for local smallholder farmers.',
      },
      items: filtered,
      total: filtered.length,
      syncedAt: daPricesLastSynced.toISOString(),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
