// 11b. Trigger DA AMAS Live Price Bulletin Sync — port of POST /api/da-prices/sync
import { NextResponse } from 'next/server';
import { daPricesCache, daPricesLastSynced, syncLatestDAPrices } from '@/veggieconnect/server/daBulletin';

export async function POST() {
  try {
    const result = await syncLatestDAPrices();
    return NextResponse.json({
      status: 'ok',
      message: 'DA Price Bulletin successfully synced with DA AMAS Price Watch.',
      result,
      totalCommodities: daPricesCache.length,
      lastSynced: daPricesLastSynced.toISOString(),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
