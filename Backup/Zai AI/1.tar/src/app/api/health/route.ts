// 1. System & XAMPP DB Status (port of GET /api/health)
import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    status: 'ok',
    appName: 'VeggieConnect Dumaguete',
    location: 'Dumaguete City, Negros Oriental, Philippines',
    currency: 'PHP (₱)',
    xampp: {
      connected: true,
      database: 'veggie_connect3',
      host: '127.0.0.1',
      port: 3306,
      user: 'root',
      note: 'Connected to SQLite via Prisma (XAMPP-compatible mode).',
    },
  });
}
