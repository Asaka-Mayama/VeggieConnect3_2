// Mark messages as read for a conversation or explicit id list — port of
// POST /api/messages/mark-read
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { ensureSeed } from '@/veggieconnect/server/helpers';
import { messageFromRow } from '@/app/api/_lib/rows';

export async function POST(req: NextRequest) {
  try {
    await ensureSeed();
    const { userId, partnerId, messageIds }: any = await req.json().catch(() => ({}));

    const rows = await db.directMessage.findMany();
    for (const row of rows) {
      const m = messageFromRow(row);
      const matchesId = Array.isArray(messageIds) && messageIds.includes(m.id);
      const matchesConversation =
        userId &&
        (m.recipientId === userId || m.farmerId === userId || m.buyerId === userId) &&
        (!partnerId ||
          m.senderId === partnerId ||
          (partnerId === 'admin-main' && m.senderRole === 'admin') ||
          m.senderRole === 'admin');

      if ((matchesId || matchesConversation) && !m.isRead) {
        const updated = { ...m, isRead: true };
        await db.directMessage.update({
          where: { id: row.id },
          data: { isRead: true, data: JSON.stringify(updated) },
        });
      }
    }

    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
