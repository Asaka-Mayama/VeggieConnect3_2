// Mark all messages addressed to a user as read — port of
// PUT /api/messages/read-all
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { ensureSeed } from '@/veggieconnect/server/helpers';
import { messageFromRow } from '@/app/api/_lib/rows';

export async function PUT(req: NextRequest) {
  try {
    await ensureSeed();
    const { userId }: any = await req.json().catch(() => ({}));
    if (!userId) return NextResponse.json({ error: 'Missing userId' }, { status: 400 });

    const rows = await db.directMessage.findMany();
    for (const row of rows) {
      const m = messageFromRow(row);
      if (m.recipientId === userId || m.farmerId === userId || (!m.recipientId && m.recipientRole === 'farmer')) {
        const updated = { ...m, isRead: true };
        await db.directMessage.update({
          where: { id: row.id },
          data: { isRead: true, data: JSON.stringify(updated) },
        });
      }
    }

    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
