// 10. Direct Messages: List and Send — port of GET / POST /api/messages.
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { asStr, ensureSeed } from '@/veggieconnect/server/helpers';
import { messageFromRow } from '@/app/api/_lib/rows';

export async function GET() {
  try {
    await ensureSeed();
    // Oldest first, exactly like the original hydration (created_ms ASC).
    const rows = await db.directMessage.findMany({
      orderBy: [{ createdAtMs: 'asc' }, { createdAt: 'asc' }],
    });
    return NextResponse.json(rows.map((row) => messageFromRow(row)));
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeed();
    const msg: any = await req.json().catch(() => ({}));
    if (!msg.id) {
      msg.id = `msg-${Date.now()}`;
    }

    // Ordering stamp: parse the client timestamp when possible, else now.
    const parsedTs = Date.parse(msg.timestamp);
    const createdMs = Number.isFinite(parsedTs) ? parsedTs : Date.now();

    const existing = await db.directMessage.findUnique({ where: { id: msg.id } });
    if (existing) {
      // Original replaced the message in place, keeping its ordering stamp.
      await db.directMessage.update({
        where: { id: msg.id },
        data: {
          senderId: asStr(msg.senderId || msg.buyerId || msg.farmerId),
          recipientId: asStr(msg.recipientId),
          isRead: Boolean(msg.isRead),
          data: JSON.stringify(msg),
        },
      });
    } else {
      await db.directMessage.create({
        data: {
          id: msg.id,
          senderId: asStr(msg.senderId || msg.buyerId || msg.farmerId),
          recipientId: asStr(msg.recipientId),
          isRead: Boolean(msg.isRead),
          data: JSON.stringify(msg),
          createdAtMs: BigInt(createdMs),
        },
      });
    }

    return NextResponse.json(msg, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
