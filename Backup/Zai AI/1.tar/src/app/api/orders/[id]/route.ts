// Order update with automatic stock restock on cancellation and transport-job
// cancellation fan-out — port of PUT /api/orders/:id
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { asStr, ensureSeed } from '@/veggieconnect/server/helpers';
import { jobFromRow, normId, orderFromRow, productFromRow } from '@/app/api/_lib/rows';

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureSeed();
    const { id } = await params;
    const updates: any = await req.json().catch(() => ({}));

    const row = await db.order.findUnique({ where: { id } });

    if (!row) {
      // Unknown order → create it from the updates (original behavior).
      const created: any = { id, ...updates };
      const now = Date.now();
      await db.order.upsert({
        where: { id },
        create: {
          id,
          status: asStr(created.status, 'pending'),
          buyerId: created.buyerId ? String(created.buyerId) : null,
          farmerId: created.farmerId !== undefined && created.farmerId !== null ? String(created.farmerId) : null,
          farmName: created.farmName ? String(created.farmName) : null,
          transportJobId: created.transportJobId ? String(created.transportJobId) : null,
          data: JSON.stringify(created),
          createdAtMs: BigInt(now),
        },
        update: {
          status: asStr(created.status, 'pending'),
          buyerId: created.buyerId ? String(created.buyerId) : null,
          farmerId: created.farmerId !== undefined && created.farmerId !== null ? String(created.farmerId) : null,
          farmName: created.farmName ? String(created.farmName) : null,
          transportJobId: created.transportJobId ? String(created.transportJobId) : null,
          data: JSON.stringify(created),
        },
      });
      return NextResponse.json(created);
    }

    const order = orderFromRow(row);
    const previousStatus = order.status;

    // Handle Order Cancellation & Automatic Stock Restock
    if (updates.status === 'cancelled' && previousStatus !== 'cancelled') {
      const items = Array.isArray(order.items) ? order.items : [];
      const prodRows = await db.product.findMany();

      for (const item of items) {
        const prodId = item?.produceId;
        const prodName = (item?.produceName || '').trim().toLowerCase();
        const qty = Number(item?.quantity) || 0;
        if (qty <= 0) continue;

        // Restock: match by produce id OR (case-insensitive) produce name.
        const matchedRow = prodRows.find((r) => {
          const p = productFromRow(r);
          return p.id === prodId || (p.name && String(p.name).trim().toLowerCase() === prodName);
        });
        if (matchedRow) {
          const p = productFromRow(matchedRow);
          p.stockQuantity = (Number(p.stockQuantity) || 0) + qty;
          if (p.sellerStatus === 'sold_out') {
            p.sellerStatus = 'bought_and_stocked';
          }
          await db.product.update({
            where: { id: matchedRow.id },
            data: {
              sellerStatus: asStr(p.sellerStatus, matchedRow.sellerStatus || 'submitted'),
              data: JSON.stringify(p),
            },
          });
        }
      }

      // Cancel any associated transport job (same matching rules as original).
      const normOrderId = normId(id);
      const jobRows = await db.transportJob.findMany();
      for (const jr of jobRows) {
        const job = jobFromRow(jr);
        const normJobOrderId = normId(job.orderId);
        const normJobId = normId(job.id);
        const normTargetJobId = normId(order.transportJobId);

        const isMatch =
          normJobOrderId === normOrderId ||
          normJobId === normOrderId ||
          (normTargetJobId && normJobId === normTargetJobId) ||
          (order.farmName &&
            job.pickupFarm &&
            String(order.farmName).trim().toLowerCase() === String(job.pickupFarm).trim().toLowerCase() &&
            order.buyerName &&
            job.buyerName &&
            String(order.buyerName).trim().toLowerCase() === String(job.buyerName).trim().toLowerCase() &&
            job.status !== 'delivered');
        if (isMatch) {
          job.status = 'cancelled';
          if (updates.cancelReason) job.cancelReason = updates.cancelReason;
          job.cancelledAt =
            updates.cancelledAt || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          await db.transportJob.update({
            where: { id: jr.id },
            data: { status: 'cancelled', data: JSON.stringify(job) },
          });
        }
      }
    }

    // Merge the updates onto the order and persist (Object.assign semantics).
    const merged = { ...order, ...updates };
    await db.order.update({
      where: { id },
      data: {
        status: asStr(merged.status, 'pending'),
        buyerId: merged.buyerId ? String(merged.buyerId) : null,
        farmerId: merged.farmerId !== undefined && merged.farmerId !== null ? String(merged.farmerId) : null,
        farmName: merged.farmName ? String(merged.farmName) : null,
        transportJobId: merged.transportJobId ? String(merged.transportJobId) : null,
        data: JSON.stringify(merged),
      },
    });

    return NextResponse.json(merged);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
