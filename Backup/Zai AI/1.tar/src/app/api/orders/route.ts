// 8. Orders: List and Create — port of GET / POST /api/orders.
// POST also deducts produce stock and auto-creates the direct-delivery
// transport job, exactly like the original server.
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { asStr, ensureSeed } from '@/veggieconnect/server/helpers';
import { jobFromRow, orderFromRow, productFromRow } from '@/app/api/_lib/rows';

export async function GET() {
  try {
    await ensureSeed();
    // Newest first (createdAtMs DESC nulls last, createdAt DESC).
    const rows = await db.order.findMany({
      orderBy: [{ createdAtMs: 'desc' }, { createdAt: 'desc' }],
    });
    return NextResponse.json(rows.map((row) => orderFromRow(row)));
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeed();
    const order: any = await req.json().catch(() => ({}));
    const createdMs = Date.now();
    const orderId = order.id || `ord-${createdMs}`;

    // Persist immediately (write-through). Upsert mirrors the original's
    // INSERT ... ON DUPLICATE KEY UPDATE for repeat ids.
    await db.order.upsert({
      where: { id: orderId },
      create: {
        id: orderId,
        status: asStr(order.status, 'pending'),
        buyerId: order.buyerId ? String(order.buyerId) : null,
        farmerId: order.farmerId !== undefined && order.farmerId !== null ? String(order.farmerId) : null,
        farmName: order.farmName ? String(order.farmName) : null,
        transportJobId: order.transportJobId ? String(order.transportJobId) : null,
        data: JSON.stringify({ ...order, id: orderId }),
        createdAtMs: BigInt(createdMs),
      },
      update: {
        status: asStr(order.status, 'pending'),
        buyerId: order.buyerId ? String(order.buyerId) : null,
        farmerId: order.farmerId !== undefined && order.farmerId !== null ? String(order.farmerId) : null,
        farmName: order.farmName ? String(order.farmName) : null,
        transportJobId: order.transportJobId ? String(order.transportJobId) : null,
        data: JSON.stringify({ ...order, id: orderId }),
      },
    });

    // Deduct stock for all ordered items in the database
    if (Array.isArray(order.items)) {
      for (const it of order.items) {
        const prodRow = it?.produceId
          ? await db.product.findUnique({ where: { id: String(it.produceId) } })
          : null;
        if (prodRow) {
          const prod = productFromRow(prodRow);
          prod.stockQuantity = Math.max(0, (prod.stockQuantity || 0) - (it.quantity || 0));
          if (prod.stockQuantity === 0 && !prod.sellerStoreName) {
            prod.sellerStatus = 'sold_out';
          }
          await db.product.update({
            where: { id: prodRow.id },
            data: {
              sellerStatus: asStr(prod.sellerStatus, prodRow.sellerStatus || 'submitted'),
              data: JSON.stringify(prod),
            },
          });
        }
      }
    }

    // If order is direct delivery (buyer delivery or supermarket procurement
    // haul), automatically create a transport job for the haul.
    if (order.deliveryType === 'direct_delivery') {
      const jobRows = await db.transportJob.findMany();
      const existingJob = jobRows.find((r) => {
        const j = jobFromRow(r);
        return (order.id && j.orderId === order.id) || (order.transportJobId && j.id === order.transportJobId);
      });
      if (!existingJob) {
        const newJob: any = {
          id: order.transportJobId || `TJ-${Date.now().toString().slice(-4)}`,
          orderId: order.id,
          pickupFarm: order.farmName,
          pickupLocation: `${order.farmName}, Negros Oriental`,
          dropoffLocation: order.deliveryAddress || 'Dumaguete City',
          buyerName: order.buyerName,
          buyerPhone: order.buyerPhone,
          itemsSummary:
            order.items?.map((it: any) => `${it.quantity} ${it.unit} ${it.produceName}`).join(', ') ||
            'Fresh produce crate',
          weightKgEst: Math.max(2, (order.items?.length || 1) * 2.5),
          earningsPeso: order.deliveryFee || 50.0,
          status: 'available',
          createdAt: 'Just now',
        };
        // Upsert mirrors saveJobToMysql's INSERT ... ON DUPLICATE KEY UPDATE.
        await db.transportJob.upsert({
          where: { id: newJob.id },
          create: {
            id: newJob.id,
            orderId: asStr(newJob.orderId),
            status: 'available',
            data: JSON.stringify(newJob),
            createdAtMs: BigInt(Date.now()),
          },
          update: {
            orderId: asStr(newJob.orderId),
            status: 'available',
            data: JSON.stringify(newJob),
          },
        });
      }
    }

    return NextResponse.json({ ...order, id: orderId }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
