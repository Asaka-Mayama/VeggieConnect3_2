// 6/7. Products: Update product details (stock, harvest status, name, price,
// photo, etc.) + Delete — port of PUT / DELETE /api/products/:id
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { asStr, ensureSeed } from '@/veggieconnect/server/helpers';
import { productFromRow } from '@/app/api/_lib/rows';

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureSeed();
    const { id } = await params;
    const updates: any = await req.json().catch(() => ({}));

    const row = await db.product.findUnique({ where: { id } });
    let item: any;

    if (!row) {
      // If not found, populate from the request body (original behavior).
      item = { id, ...updates };
      await db.product.create({
        data: {
          id,
          farmerId: asStr(item.farmerId),
          farmerName: asStr(item.farmerName),
          farmName: asStr(item.farmName),
          name: asStr(item.name),
          sellerStatus: asStr(item.sellerStatus, 'submitted'),
          sellerStoreName: item.sellerStoreName || null,
          data: JSON.stringify(item),
        },
      });
    } else {
      // Object.assign semantics: updates win over the existing canonical JSON.
      item = { ...productFromRow(row), ...updates };
      await db.product.update({
        where: { id },
        data: {
          name: updates.name !== undefined ? asStr(updates.name) : row.name,
          farmName: updates.farmName !== undefined ? asStr(updates.farmName) : row.farmName,
          farmerName: updates.farmerName !== undefined ? asStr(updates.farmerName) : row.farmerName,
          sellerStatus:
            updates.sellerStatus !== undefined ? asStr(updates.sellerStatus, 'submitted') : row.sellerStatus,
          sellerStoreName:
            updates.sellerStoreName !== undefined ? updates.sellerStoreName || null : row.sellerStoreName,
          data: JSON.stringify(item),
        },
      });
    }

    return NextResponse.json(item);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureSeed();
    const { id } = await params;
    await db.product.deleteMany({ where: { id } });
    return NextResponse.json({ success: true, message: 'Product deleted' });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
