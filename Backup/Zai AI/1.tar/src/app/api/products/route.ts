// 4/5. Products: List all + Create new / Upsert — port of GET / POST /api/products
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { asStr, ensureSeed } from '@/veggieconnect/server/helpers';
import { productFromRow } from '@/app/api/_lib/rows';

export async function GET() {
  try {
    await ensureSeed();
    const rows = await db.product.findMany({ orderBy: { createdAt: 'desc' } });
    return NextResponse.json(rows.map((row) => productFromRow(row)));
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeed();
    const p: any = await req.json().catch(() => ({}));
    const stockParsed = parseInt(p.stockQuantity, 10);
    const newProduct: any = {
      id: p.id || `prod-${Date.now()}`,
      farmerId: p.farmerId || 'farmer-1',
      farmerName: p.farmerName || 'Local Farmer',
      farmName: p.farmName || 'Local Farm',
      name: p.name,
      category: p.category || 'Leafy Greens',
      variety: p.variety || '',
      pricePerUnit: parseFloat(p.pricePerUnit) || 45.0,
      unit: p.unit || 'kg',
      stockQuantity: !isNaN(stockParsed) ? stockParsed : 20,
      minOrderQuantity: parseInt(p.minOrderQuantity, 10) || 1,
      harvestStatus: p.harvestStatus || 'Harvested Today',
      harvestDate: p.harvestDate || 'Today at 06:00 AM',
      farmingMethod: p.farmingMethod || 'Naturally Grown',
      imageUrl: p.imageUrl || '',
      isOrganic: Boolean(p.isOrganic),
      description: p.description || 'Fresh harvest in Negros Oriental.',
      location: p.location || 'Dumaguete City, Negros Oriental',
      latitude: p.latitude !== undefined && !isNaN(parseFloat(p.latitude)) ? parseFloat(p.latitude) : undefined,
      longitude: p.longitude !== undefined && !isNaN(parseFloat(p.longitude)) ? parseFloat(p.longitude) : undefined,
      distanceKm: p.distanceKm || 3.5,
      rating: 5.0,
      reviewsCount: 1,
      sellerStatus: p.sellerStatus || 'submitted',
      brokerStatus: p.brokerStatus || 'approved_active',
      sellerStoreName: p.sellerStoreName || undefined,
      farmgateAskingPrice: p.farmgateAskingPrice !== undefined ? parseFloat(p.farmgateAskingPrice) : undefined,
      boughtQuantity: p.boughtQuantity || 0,
      boughtAt: p.boughtAt || undefined,
      sourcingRegion: p.sourcingRegion || undefined,
    };

    // Supermarket stocking dedup: identical supermarket produce merges stock.
    const isSm =
      newProduct.sellerStoreName === 'VeggieConnect Supermarket' ||
      newProduct.sellerStatus === 'bought_and_stocked' ||
      newProduct.id.startsWith('sm-');
    const norm = (s: string) => (s || '').toLowerCase().replace(/\(.*?\)/g, '').replace(/[^a-z0-9]/g, '').trim();

    const allRows = await db.product.findMany({ orderBy: { createdAt: 'desc' } });
    let existingRow = allRows.find((r) => r.id === newProduct.id) || null;
    if (!existingRow && isSm) {
      existingRow =
        allRows.find((r) => {
          const prod = productFromRow(r);
          const prodIsSm =
            prod.sellerStoreName === 'VeggieConnect Supermarket' ||
            prod.sellerStatus === 'bought_and_stocked' ||
            (prod.id && prod.id.startsWith('sm-'));
          return prodIsSm && norm(prod.name) === norm(newProduct.name);
        }) || null;
    }

    let responseProduct = newProduct;

    if (existingRow) {
      const existing = productFromRow(existingRow);
      newProduct.id = existing.id;
      newProduct.stockQuantity = (existing.stockQuantity || 0) + (newProduct.stockQuantity || 0);
      newProduct.boughtQuantity = Math.max(
        existing.boughtQuantity || 0,
        newProduct.boughtQuantity || 0,
        newProduct.stockQuantity
      );
      // Same spread semantics as the original: existing fields first, then the
      // new payload wins (undefined-valued keys are dropped by JSON.stringify).
      const merged = { ...existing, ...newProduct };
      responseProduct = newProduct;

      await db.product.update({
        where: { id: existing.id },
        data: {
          farmerId: asStr(merged.farmerId),
          farmerName: asStr(merged.farmerName),
          farmName: asStr(merged.farmName),
          name: asStr(merged.name),
          sellerStatus: asStr(merged.sellerStatus, 'submitted'),
          sellerStoreName: merged.sellerStoreName || null,
          data: JSON.stringify(merged),
        },
      });
    } else {
      await db.product.create({
        data: {
          id: newProduct.id,
          farmerId: asStr(newProduct.farmerId),
          farmerName: asStr(newProduct.farmerName),
          farmName: asStr(newProduct.farmName),
          name: asStr(newProduct.name),
          sellerStatus: asStr(newProduct.sellerStatus, 'submitted'),
          sellerStoreName: newProduct.sellerStoreName || null,
          data: JSON.stringify(newProduct),
        },
      });
    }

    return NextResponse.json(responseProduct, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
