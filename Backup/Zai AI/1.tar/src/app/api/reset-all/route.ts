// Reset / Purge all data to start completely fresh — port of POST /api/reset-all.
// Disabled by default so nobody can wipe the real demo data by accident.
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { DEMO_RESET_ENABLED, ensureSeed } from '@/veggieconnect/server/helpers';

export async function POST() {
  try {
    await ensureSeed();
    if (!DEMO_RESET_ENABLED) {
      return NextResponse.json(
        { error: 'Demo reset is disabled. Set VITE_ENABLE_DEMO_RESET=true in .env to allow it.' },
        { status: 403 }
      );
    }

    await db.product.deleteMany({});
    await db.order.deleteMany({});
    await db.transportJob.deleteMany({});
    await db.directMessage.deleteMany({});
    await db.user.deleteMany({ where: { NOT: { email: 'admin@gmail.com' } } });

    return NextResponse.json({ success: true, message: 'All demo and mock data wiped clean' });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
