// Supermarket hub location pinned from Admin > Profile — port of
// GET / PUT /api/supermarket. Shared singleton so a farmer's device can always
// see the admin's deliberate pin (localStorage alone is per-browser).
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { ensureSeed } from '@/veggieconnect/server/helpers';

/** BigInt `savedAt` column -> plain number for the JSON payload. */
function serializeHub(row: any): any {
  if (!row) return row;
  const savedAt = Number(row.savedAt ?? 0);
  return {
    storeName: row.storeName,
    address: row.address,
    latitude: row.latitude,
    longitude: row.longitude,
    ...(savedAt > 0 ? { savedAt } : {}),
  };
}

export async function GET() {
  try {
    await ensureSeed();
    const row = await db.supermarketConfig.findUnique({ where: { id: 'main' } });
    return NextResponse.json(row ? serializeHub(row) : {});
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    await ensureSeed();
    const body: any = await req.json().catch(() => ({}));
    const { storeName, address, latitude, longitude, savedAt } = body || {};
    const lat = typeof latitude === 'number' ? latitude : parseFloat(latitude);
    const lng = typeof longitude === 'number' ? longitude : parseFloat(longitude);
    if (isNaN(lat) || isNaN(lng)) {
      return NextResponse.json({ error: 'latitude and longitude are required' }, { status: 400 });
    }

    const current = await db.supermarketConfig.findUnique({ where: { id: 'main' } });
    const base = current ? serializeHub(current) : {};

    const updated: any = {
      ...base,
      ...(storeName ? { storeName } : {}),
      ...(address ? { address } : {}),
      latitude: lat,
      longitude: lng,
      ...(typeof savedAt === 'number' ? { savedAt } : {}),
    };

    const persistedSavedAt = BigInt(
      typeof updated.savedAt === 'number' ? Math.trunc(updated.savedAt) : Number(current?.savedAt ?? 0)
    );

    await db.supermarketConfig.upsert({
      where: { id: 'main' },
      create: {
        id: 'main',
        storeName: updated.storeName || 'VeggieConnect Central Supermarket Hub',
        address: updated.address || '',
        latitude: lat,
        longitude: lng,
        savedAt: persistedSavedAt,
      },
      update: {
        storeName: updated.storeName || 'VeggieConnect Central Supermarket Hub',
        address: updated.address || '',
        latitude: lat,
        longitude: lng,
        savedAt: persistedSavedAt,
      },
    });

    return NextResponse.json({ success: true, supermarket: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
