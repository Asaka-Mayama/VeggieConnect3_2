// Transport job update with automatic order synchronization — port of
// PUT /api/transport-jobs/:id
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { asStr, ensureSeed } from '@/veggieconnect/server/helpers';
import { JOB_STATUSES, jobFromRow, orderFromRow } from '@/app/api/_lib/rows';

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureSeed();
    const { id } = await params;
    const body: any = await req.json().catch(() => ({}));
    const { status, assignedTransporterId, assignedTransporterName, cancelReason, cancelledAt } = body;

    const row = await db.transportJob.findUnique({ where: { id } });
    if (!row) return NextResponse.json({ error: 'Transport job not found' }, { status: 404 });

    const job = jobFromRow(row);
    if (status) job.status = status;
    if (assignedTransporterId) job.assignedTransporterId = assignedTransporterId;
    if (assignedTransporterName) job.assignedTransporterName = assignedTransporterName;
    if (cancelReason) job.cancelReason = cancelReason;
    if (cancelledAt) job.cancelledAt = cancelledAt;

    // Crucial: Automatically synchronize the corresponding order (if not cancelled)
    const orderRows = await db.order.findMany();
    const matchedOrderRow = orderRows.find((r) => {
      const o = orderFromRow(r);
      return (
        (job.orderId && o.id === job.orderId) ||
        (o.transportJobId && o.transportJobId === job.id) ||
        (o.farmName &&
          job.pickupFarm &&
          String(o.farmName).trim().toLowerCase() === String(job.pickupFarm).trim().toLowerCase() &&
          o.buyerName &&
          job.buyerName &&
          String(o.buyerName).trim().toLowerCase() === String(job.buyerName).trim().toLowerCase() &&
          o.status !== 'completed')
      );
    });

    if (matchedOrderRow) {
      const matchedOrder = orderFromRow(matchedOrderRow);
      if (matchedOrder.status !== 'cancelled') {
        if (assignedTransporterId) matchedOrder.transporterId = assignedTransporterId;
        if (assignedTransporterName) matchedOrder.transporterName = assignedTransporterName;

        if (status === 'accepted' || status === 'picked_up' || status === 'in_transit') {
          matchedOrder.status = 'in_transit';
        } else if (status === 'delivered') {
          matchedOrder.status = 'completed';
        }
        await db.order.update({
          where: { id: matchedOrderRow.id },
          data: {
            status: asStr(matchedOrder.status, 'pending'),
            data: JSON.stringify(matchedOrder),
          },
        });
      }
    }

    await db.transportJob.update({
      where: { id },
      data: {
        status: JOB_STATUSES.includes(job.status) ? job.status : 'available',
        data: JSON.stringify(job),
      },
    });

    return NextResponse.json(job);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
