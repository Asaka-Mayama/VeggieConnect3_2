// 9. Transport Jobs: List and Create — port of GET / POST /api/transport-jobs.
// (PUT /api/transport-jobs/:id lives in ./[id]/route.ts)
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { asStr, ensureSeed } from '@/veggieconnect/server/helpers';
import { JOB_STATUSES, jobFromRow, normId, orderFromRow } from '@/app/api/_lib/rows';

export async function GET() {
  try {
    await ensureSeed();
    // Newest first (createdAtMs DESC nulls last, createdAt DESC).
    const jobRows = await db.transportJob.findMany({
      orderBy: [{ createdAtMs: 'desc' }, { createdAt: 'desc' }],
    });
    const orderRows = await db.order.findMany();
    const orders = orderRows.map((r) => orderFromRow(r));

    const jobs: any[] = [];
    for (const jr of jobRows) {
      const job = jobFromRow(jr);

      // Ensure consistency: if linked order is cancelled, the job is cancelled
      const normJobOrderId = normId(job.orderId);
      const normJobId = normId(job.id);
      const linked = orders.find((o) => {
        const normOId = normId(o.id);
        const normTargetJobId = normId(o.transportJobId);
        return (
          normOId === normJobOrderId ||
          normOId === normJobId ||
          (normTargetJobId && normJobId === normTargetJobId) ||
          (o.farmName &&
            job.pickupFarm &&
            String(o.farmName).trim().toLowerCase() === String(job.pickupFarm).trim().toLowerCase() &&
            o.buyerName &&
            job.buyerName &&
            String(o.buyerName).trim().toLowerCase() === String(job.buyerName).trim().toLowerCase() &&
            job.status !== 'delivered')
        );
      });
      if (linked && linked.status === 'cancelled') {
        job.status = 'cancelled';
        if (linked.cancelReason && !job.cancelReason) job.cancelReason = linked.cancelReason;
        if (linked.cancelledAt && !job.cancelledAt) job.cancelledAt = linked.cancelledAt;
        await db.transportJob.update({
          where: { id: jr.id },
          data: { status: 'cancelled', data: JSON.stringify(job) },
        });
      }
      jobs.push(job);
    }

    return NextResponse.json(jobs);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeed();
    const job: any = await req.json().catch(() => ({}));
    const jobId = job.id || `TJ-${Date.now().toString().slice(-4)}`;

    const existing = await db.transportJob.findUnique({ where: { id: jobId } });
    if (existing) {
      const merged = { ...jobFromRow(existing), ...job };
      await db.transportJob.update({
        where: { id: jobId },
        data: {
          orderId: asStr(merged.orderId),
          status: JOB_STATUSES.includes(merged.status) ? merged.status : 'available',
          data: JSON.stringify(merged),
        },
      });
    } else {
      await db.transportJob.create({
        data: {
          id: jobId,
          orderId: asStr(job.orderId),
          status: JOB_STATUSES.includes(job.status) ? job.status : 'available',
          data: JSON.stringify(job),
          createdAtMs: BigInt(Date.now()),
        },
      });
    }

    return NextResponse.json({ ...job, id: jobId }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
