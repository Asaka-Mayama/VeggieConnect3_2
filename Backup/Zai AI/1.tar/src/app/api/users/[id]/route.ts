// Update User Profile (User & Admin editing) + Delete User with cascading
// cleanup of their products — ports of PUT / DELETE /api/users/:id
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { asStr, ensureSeed, safeUser, VALID_ROLES } from '@/veggieconnect/server/helpers';
import { productFromRow, userFromRow } from '@/app/api/_lib/rows';

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureSeed();
    const { id } = await params;
    const body: any = await req.json().catch(() => ({}));
    const { name, email, phone, role, location, latitude, longitude, farmName, avatar, verified, status, bio } = body;

    const row = await db.user.findUnique({ where: { id } });

    if (row) {
      const existing = userFromRow(row);
      const merged: any = {
        ...existing,
        name: name !== undefined ? name : existing.name,
        email: email !== undefined ? email : existing.email,
        phone: phone !== undefined ? phone : existing.phone,
        role: role !== undefined && VALID_ROLES.includes(role) ? role : existing.role,
        location: location !== undefined ? location : existing.location,
        latitude:
          latitude !== undefined
            ? latitude !== null && !isNaN(parseFloat(latitude))
              ? parseFloat(latitude)
              : undefined
            : existing.latitude,
        longitude:
          longitude !== undefined
            ? longitude !== null && !isNaN(parseFloat(longitude))
              ? parseFloat(longitude)
              : undefined
            : existing.longitude,
        farmName: farmName !== undefined ? farmName : existing.farmName,
        avatar: avatar !== undefined ? avatar : existing.avatar,
        verified: verified !== undefined ? verified : existing.verified,
        status: status !== undefined ? status : existing.status,
        bio: bio !== undefined ? bio : existing.bio,
      };

      await db.user.update({
        where: { id },
        data: {
          name: asStr(merged.name, row.name),
          email:
            merged.email !== undefined && merged.email !== null ? String(merged.email) : row.email,
          phone: asStr(merged.phone),
          role: asStr(merged.role, row.role),
          data: JSON.stringify(merged),
        },
      });

      return NextResponse.json({
        success: true,
        message: 'User profile updated successfully',
        user: safeUser(merged),
      });
    }

    // User row missing entirely → create it from the request body, exactly
    // like the original's in-memory push of `{ id, ...req.body }`.
    const created: any = { id, ...body };
    const stored = { ...created };
    delete stored.password_hash;
    delete stored.passwordHash;

    let emailToUse = created.email ? String(created.email) : `${id}@veggieconnect.ph`;
    const emailTaken = await db.user.findFirst({ where: { email: emailToUse, id: { not: id } } });
    if (emailTaken) emailToUse = `${id}-${Date.now()}@veggieconnect.local`;

    await db.user.create({
      data: {
        id,
        name: asStr(created.name, id),
        email: emailToUse,
        phone: asStr(created.phone),
        role: asStr(created.role, 'buyer'),
        passwordHash: asStr(created.passwordHash || created.password_hash),
        data: JSON.stringify(stored),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'User profile updated successfully',
      user: safeUser(created),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureSeed();
    const { id } = await params;
    const row = await db.user.findUnique({ where: { id } });
    const userToDelete = row ? userFromRow(row) : null;

    // Cascading deletion: remove all products listed by this farmer
    // (farmerId match, or farm-name / farmer-name match, case-insensitive).
    const allProducts = await db.product.findMany();
    const doomedIds = allProducts
      .filter((pr) => {
        const p = productFromRow(pr);
        if (p.farmerId === id) return true;
        if (
          userToDelete?.farmName &&
          p.farmName &&
          String(p.farmName).trim().toLowerCase() === String(userToDelete.farmName).trim().toLowerCase()
        )
          return true;
        if (
          userToDelete?.name &&
          p.farmerName &&
          String(p.farmerName).trim().toLowerCase() === String(userToDelete.name).trim().toLowerCase()
        )
          return true;
        return false;
      })
      .map((pr) => pr.id);

    if (doomedIds.length > 0) {
      await db.product.deleteMany({ where: { id: { in: doomedIds } } });
    }
    if (row) {
      await db.user.delete({ where: { id } });
    }

    return NextResponse.json({ success: true, message: 'User and all associated listings deleted successfully' });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
