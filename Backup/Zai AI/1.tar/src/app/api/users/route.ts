// List all registered users (for chat contact directory and farmer discovery)
// — port of GET /api/users. Returns the canonical `data` profile JSON of every
// user except retired transporter accounts; password hashes are never exposed.
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { ensureSeed, isRetiredAccount, safeUser } from '@/veggieconnect/server/helpers';
import { userFromRow } from '@/app/api/_lib/rows';

export async function GET() {
  try {
    await ensureSeed();
    const rows = await db.user.findMany({ orderBy: { createdAt: 'asc' } });
    const users = rows
      .map((row) => userFromRow(row))
      .filter((u) => !isRetiredAccount(u))
      .map((u) => safeUser(u));
    return NextResponse.json(users);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
