// 12. XAMPP SQL Dump Generator for phpMyAdmin — port of GET /api/xampp/export.
// Returns the exact same SQL dump template as the original Express server.
export async function GET() {
  const sqlDump = `-- =========================================================================
-- VeggieConnect 3: Direct Agricultural Marketplace & Buyer-Led Fulfillment
-- Complete XAMPP MySQL / MariaDB Database Export
-- Target Platform: XAMPP (Apache + MySQL/MariaDB + PHP + phpMyAdmin)
-- Database: veggie_connect3
-- Host: localhost:3306 | User: root | Password: (blank)
-- Location: Dumaguete City, Negros Oriental, Philippines
-- Currency: Philippine Peso (PHP / ₱)
-- Roles: Farmer, Buyer, Admin (the admin also handles deliveries)
-- Generated on: ${new Date().toISOString()}
-- =========================================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+08:00";

CREATE DATABASE IF NOT EXISTS \`veggie_connect3\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE \`veggie_connect3\`;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS \`direct_messages\`;
DROP TABLE IF EXISTS \`transport_jobs\`;
DROP TABLE IF EXISTS \`procurement_deals\`;
DROP TABLE IF EXISTS \`orders\`;
DROP TABLE IF EXISTS \`products\`;
DROP TABLE IF EXISTS \`da_price_bulletin\`;
DROP TABLE IF EXISTS \`users\`;

-- --------------------------------------------------------
-- Table structure for \`users\`
-- --------------------------------------------------------
CREATE TABLE \`users\` (
  \`id\` VARCHAR(64) NOT NULL,
  \`name\` VARCHAR(120) NOT NULL,
  \`email\` VARCHAR(120) NOT NULL,
  \`password_hash\` VARCHAR(255) NOT NULL DEFAULT '8f94e6b12a:1849a9fb92a',
  \`phone\` VARCHAR(50) NOT NULL,
  \`role\` ENUM('farmer', 'buyer', 'admin') NOT NULL,
  \`location\` VARCHAR(200) NOT NULL,
  \`farm_name\` VARCHAR(150) DEFAULT NULL,
  \`avatar_url\` VARCHAR(255) DEFAULT NULL,
  \`status\` ENUM('active', 'pending', 'suspended') NOT NULL DEFAULT 'active',
  \`is_verified\` TINYINT(1) NOT NULL DEFAULT 1,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`),
  UNIQUE KEY \`unique_email\` (\`email\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for \`products\` (Brokered Produce & Farmer Harvest Lots)
-- --------------------------------------------------------
CREATE TABLE \`products\` (
  \`id\` VARCHAR(64) NOT NULL,
  \`farmer_id\` VARCHAR(64) NOT NULL,
  \`farmer_name\` VARCHAR(120) NOT NULL,
  \`farm_name\` VARCHAR(150) NOT NULL,
  \`name\` VARCHAR(150) NOT NULL,
  \`category\` VARCHAR(60) NOT NULL,
  \`variety\` VARCHAR(100) DEFAULT NULL,
  \`farmgate_asking_price\` DECIMAL(10,2) NOT NULL DEFAULT 40.00,
  \`price_per_unit\` DECIMAL(10,2) NOT NULL,
  \`unit\` VARCHAR(30) NOT NULL,
  \`stock_quantity\` INT(11) NOT NULL DEFAULT 0,
  \`min_order_quantity\` INT(11) NOT NULL DEFAULT 1,
  \`harvest_status\` VARCHAR(60) NOT NULL,
  \`harvest_date\` VARCHAR(100) NOT NULL,
  \`farming_method\` VARCHAR(60) NOT NULL,
  \`image_url\` TEXT DEFAULT NULL,
  \`is_organic\` TINYINT(1) DEFAULT 0,
  \`description\` TEXT DEFAULT NULL,
  \`location\` VARCHAR(150) NOT NULL,
  \`distance_km\` DECIMAL(5,2) DEFAULT 3.50,
  \`rating\` DECIMAL(3,2) DEFAULT 5.00,
  \`reviews_count\` INT(11) DEFAULT 0,
  \`broker_status\` ENUM('pending_review', 'approved_active', 'sold_out', 'archived') NOT NULL DEFAULT 'approved_active',
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for \`orders\` (Broker Marketplace Orders)
-- --------------------------------------------------------
CREATE TABLE \`orders\` (
  \`id\` VARCHAR(64) NOT NULL,
  \`buyer_name\` VARCHAR(120) NOT NULL,
  \`buyer_phone\` VARCHAR(50) NOT NULL,
  \`delivery_type\` ENUM('farm_pickup', 'direct_delivery') NOT NULL,
  \`delivery_address\` TEXT DEFAULT NULL,
  \`pickup_slot\` VARCHAR(150) DEFAULT NULL,
  \`subtotal\` DECIMAL(10,2) NOT NULL,
  \`delivery_fee\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`total_amount\` DECIMAL(10,2) NOT NULL,
  \`payment_method\` VARCHAR(100) NOT NULL,
  \`status\` ENUM('pending', 'confirmed', 'harvesting_packing', 'ready_for_pickup_delivery', 'picked_up', 'in_transit', 'completed', 'cancelled') NOT NULL DEFAULT 'pending',
  \`farmer_id\` VARCHAR(64) NOT NULL,
  \`farm_name\` VARCHAR(150) NOT NULL,
  \`notes\` TEXT DEFAULT NULL,
  \`transporter_id\` VARCHAR(64) DEFAULT NULL,
  \`transporter_name\` VARCHAR(120) DEFAULT NULL,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for \`transport_jobs\`
-- --------------------------------------------------------
CREATE TABLE \`transport_jobs\` (
  \`id\` VARCHAR(64) NOT NULL,
  \`order_id\` VARCHAR(64) NOT NULL,
  \`pickup_farm\` VARCHAR(150) NOT NULL,
  \`pickup_location\` VARCHAR(200) NOT NULL,
  \`dropoff_location\` VARCHAR(200) NOT NULL,
  \`buyer_name\` VARCHAR(120) NOT NULL,
  \`buyer_phone\` VARCHAR(50) NOT NULL,
  \`items_summary\` TEXT NOT NULL,
  \`weight_kg_est\` DECIMAL(6,2) NOT NULL DEFAULT 1.00,
  \`earnings_peso\` DECIMAL(10,2) NOT NULL,
  \`status\` ENUM('available', 'accepted', 'picked_up', 'in_transit', 'delivered') NOT NULL DEFAULT 'available',
  \`assigned_transporter_id\` VARCHAR(64) DEFAULT NULL,
  \`assigned_transporter_name\` VARCHAR(120) DEFAULT NULL,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for \`direct_messages\`
-- --------------------------------------------------------
CREATE TABLE \`direct_messages\` (
  \`id\` VARCHAR(64) NOT NULL,
  \`sender_id\` VARCHAR(64) NOT NULL,
  \`sender_name\` VARCHAR(120) NOT NULL,
  \`sender_role\` ENUM('farmer', 'buyer', 'admin') NOT NULL,
  \`recipient_id\` VARCHAR(64) NOT NULL,
  \`recipient_name\` VARCHAR(120) NOT NULL,
  \`recipient_role\` ENUM('farmer', 'buyer', 'admin') NOT NULL,
  \`text\` TEXT NOT NULL,
  \`produce_name\` VARCHAR(150) DEFAULT NULL,
  \`order_id\` VARCHAR(64) DEFAULT NULL,
  \`is_read\` TINYINT(1) DEFAULT 0,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert Admin Account
INSERT INTO \`users\` (\`id\`, \`name\`, \`email\`, \`password_hash\`, \`phone\`, \`role\`, \`location\`, \`status\`, \`is_verified\`) VALUES
('admin-main', 'VeggieConnect Broker Desk', 'admin@gmail.com', '8f94e6b12a:1849a9fb92a', '+63 900 000 0000', 'admin', 'Dumaguete City Proper (Central Broker Hub)', 'active', 1)
ON DUPLICATE KEY UPDATE \`name\` = VALUES(\`name\`);

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
`;

  return new Response(sqlDump, {
    headers: {
      'Content-Type': 'application/sql',
      'Content-Disposition': 'attachment; filename="veggie_connect3.sql"',
    },
  });
}
