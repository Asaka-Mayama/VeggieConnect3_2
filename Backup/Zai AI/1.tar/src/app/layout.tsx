import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "VeggieConnect",
  description:
    "Direct vegetable market mobile application connecting farmers and buyers with live chat, farm-gate orders, and administrative user management.",
  keywords: [
    "VeggieConnect",
    "farmers",
    "buyers",
    "marketplace",
    "Dumaguete",
    "Negros Oriental",
    "farm-gate",
  ],
  openGraph: {
    title: "VeggieConnect",
    description:
      "Direct vegetable market connecting farmers and buyers with live chat, farm-gate orders, and administrative user management.",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1.0,
  maximumScale: 1.0,
  userScalable: false,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased bg-white text-foreground">{children}</body>
    </html>
  );
}
