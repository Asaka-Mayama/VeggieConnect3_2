'use client';

import dynamic from 'next/dynamic';

// VeggieConnect is a client-side SPA that reads localStorage/sessionStorage on
// mount (login sessions, cart, live sync bus). It must render browser-only.
const VeggieConnectApp = dynamic(
  () => import('@/veggieconnect/VeggieConnectApp'),
  {
    ssr: false,
    loading: () => (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-lime-50">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-green-600 border-t-transparent" />
          <p className="text-sm font-medium text-green-800">
            Loading VeggieConnect…
          </p>
        </div>
      </div>
    ),
  }
);

export default function Page() {
  return <VeggieConnectApp />;
}
