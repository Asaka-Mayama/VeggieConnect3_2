import 'server-only';
import crypto from 'crypto';
import { db } from '@/lib/db';

// ---------------------------------------------------------------------------
// Shared backend helpers for the VeggieConnect API routes.
// Mirrors the utilities inside the original Express server (server.ts) so the
// API payloads and behaviors stay 1:1 with the source repository.
// ---------------------------------------------------------------------------

/** Password for admin@gmail.com (overridable via env, defaults like the original). */
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';

/** The "wipe all data" endpoint stays OFF unless explicitly enabled. */
export const DEMO_RESET_ENABLED = process.env.VITE_ENABLE_DEMO_RESET === 'true';

export const VALID_ROLES = ['buyer', 'farmer', 'admin'];
export const isRetiredAccount = (u: any) => !!u && u.role === 'transporter';

export function passwordsMatch(supplied: string, expected: string): boolean {
  const a = Buffer.from(String(supplied));
  const b = Buffer.from(String(expected));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// --- Password Hashing & Verification (same format as the original server) ---
export function hashPassword(password: string): string {
  if (!password) password = 'default_secure_pass';
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash?: string): boolean {
  if (!storedHash) return false;
  // Handle plain text passwords gracefully for backwards compatibility
  if (!storedHash.includes(':')) {
    return storedHash === password;
  }
  const parts = storedHash.split(':');
  if (parts.length !== 2) return storedHash === password;
  const [salt, key] = parts;
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return key === hash;
}

export function normalizePhone(p?: string): string {
  if (!p) return '';
  return p.replace(/[\s\-\+\(\)]/g, '').replace(/^63/, '0');
}

export function toOptionalNumber(value: any): number | undefined {
  if (value === undefined || value === null || value === '') return undefined;
  const n = typeof value === 'number' ? value : parseFloat(value);
  return Number.isFinite(n) ? n : undefined;
}

export const asStr = (v: any, d = '') => (v === undefined || v === null ? d : String(v));
export const asNum = (v: any, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

/** Strips the password hash before sending a user record to any client. */
export function safeUser(u: any): any {
  if (!u) return u;
  const copy = { ...u };
  delete copy.password_hash;
  delete copy.passwordHash;
  return copy;
}

export const DEFAULT_ADMIN = {
  id: 'admin-main',
  name: 'VeggieConnect Admin Desk',
  email: 'admin@gmail.com',
  phone: '+63 900 000 0000',
  role: 'admin',
  location: 'Rizal Boulevard & Port Area, Dumaguete City Proper, Negros Oriental',
  latitude: 9.308,
  longitude: 123.3105,
  verified: true,
  status: 'active',
  avatar: '',
  farmName: undefined as string | undefined,
};

/**
 * Guarantees the system admin account + default supermarket hub exist.
 * Called lazily by API routes (idempotent, cheap after first run).
 */
export async function ensureSeed(): Promise<void> {
  try {
    const admin = await db.user.findUnique({ where: { id: 'admin-main' } });
    if (!admin) {
      await db.user.create({
        data: {
          id: DEFAULT_ADMIN.id,
          name: DEFAULT_ADMIN.name,
          email: DEFAULT_ADMIN.email,
          phone: DEFAULT_ADMIN.phone,
          role: 'admin',
          passwordHash: '',
          data: JSON.stringify(DEFAULT_ADMIN),
        },
      });
    }
    const hub = await db.supermarketConfig.findUnique({ where: { id: 'main' } });
    if (!hub) {
      await db.supermarketConfig.create({
        data: {
          id: 'main',
          storeName: 'VeggieConnect Central Supermarket Hub',
          address: 'Rizal Boulevard & Port Area, Dumaguete City Proper, Negros Oriental',
          latitude: 9.308,
          longitude: 123.3105,
          savedAt: 0,
        },
      });
    }
  } catch (e) {
    console.error('[VeggieConnect seed] notice:', e);
  }
}

// ---------------------------------------------------------------------------
// Canonical JSON `data` column helpers (orders / jobs / messages / users /
// products all persist the exact object the frontend produced, mirroring the
// original server's MySQL `data LONGTEXT` write-through pattern).
// ---------------------------------------------------------------------------
export function parseData<T = any>(raw: string | null | undefined, fallback: T | null = null): T | null {
  if (!raw) return fallback;
  try {
    const obj = JSON.parse(raw);
    return obj;
  } catch {
    return fallback;
  }
}

export function parseRecord(raw: string | null | undefined): any | null {
  const obj = parseData(raw);
  return obj && typeof obj === 'object' && obj.id ? obj : null;
}
