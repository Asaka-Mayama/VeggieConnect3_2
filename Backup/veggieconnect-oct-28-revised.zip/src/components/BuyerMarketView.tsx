import React, { useState, useMemo } from 'react';
import {
  Search,
  SlidersHorizontal,
  Flame,
  MapPin,
  ArrowUpDown,
  Plus,
  ClipboardList,
  Sparkles,
  ArrowRight,
  Store,
  Sprout,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { ProduceItem, HarvestStatus } from '../types';
import { ProduceCard } from './ProduceCard';
import { DA_DAILY_PRICES } from '../data/daPricesData';

interface BuyerMarketViewProps {
  produceList: ProduceItem[];
  onSelectProduce: (produce: ProduceItem) => void;
  onAddToCart: (produce: ProduceItem, e: React.MouseEvent) => void;
  cartItemIds: Set<string>;
  isBuyer?: boolean;
  onOpenCart?: () => void;
  cartCount?: number;
}

// Master regional vegetable items (so buyers always have a full catalog of vegetables to request from local farmers)
const REGIONAL_MARKET_CROPS: ProduceItem[] = DA_DAILY_PRICES.map((da, idx) => ({
  id: `da-crop-${da.id}`,
  farmerId: 'farmer-local-network',
  farmerName: 'Negros Oriental Farmer Network',
  farmName: 'Local Registered Farm Partner',
  name: da.commodity,
  category: da.category,
  variety: da.variety || da.localName || 'Native Crop',
  farmgateAskingPrice: da.prevailingFarmgatePrice,
  pricePerUnit: da.suggestedDirectFarmPrice || da.prevailingRetailPrice,
  unit: da.unit || 'kg',
  stockQuantity: 999,
  minOrderQuantity: 1,
  harvestStatus: 'Fresh Picked on Order',
  harvestDate: 'Harvested on Order',
  farmingMethod: 'Naturally Grown (Negros Local Growers)',
  imageUrl: [
    'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80', // Tomato
    'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?auto=format&fit=crop&w=600&q=80', // Carrot
    'https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=600&q=80', // Potato
    'https://images.unsplash.com/photo-1566385101042-1a0aa0c1268c?auto=format&fit=crop&w=600&q=80', // Veggies
    'https://images.unsplash.com/photo-1508747703725-719777637510?auto=format&fit=crop&w=600&q=80', // Greens
    'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80', // Pepper
  ][idx % 6],
  isOrganic: true,
  description: `Locally grown ${da.commodity} available for sourcing from registered farmers in Dumaguete & Valencia.`,
  sourcingRegion: 'Valencia Volcanic Slopes / Dumaguete',
  location: 'Dumaguete City, Negros Oriental',
  distanceKm: 3.5,
  rating: 5.0,
  reviewsCount: 12,
  sellerStatus: 'submitted',
}));

export const BuyerMarketView: React.FC<BuyerMarketViewProps> = ({
  produceList,
  onSelectProduce,
  onAddToCart,
  cartItemIds,
  isBuyer = true,
  onOpenCart,
  cartCount = 0,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [maxDistance, setMaxDistance] = useState<number>(100);
  const [sortBy, setSortBy] = useState<'freshness' | 'price_low' | 'distance'>('freshness');
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);

  // Custom Request Modal State
  const [showCustomModal, setShowCustomModal] = useState(false);
  const [customVegName, setCustomVegName] = useState('');
  const [customVegQty, setCustomVegQty] = useState(5);
  const [customVegUnit, setCustomVegUnit] = useState('kg');
  const [customVegNotes, setCustomVegNotes] = useState('');

  // Combined vegetable catalog: Farmer-listed crops + regional harvest options
  const allAvailableCrops = useMemo(() => {
    const list: ProduceItem[] = [];
    const knownNames = new Set<string>();

    // Add farmer-submitted crops first
    if (Array.isArray(produceList)) {
      produceList.forEach((p) => {
        if (!p || !p.name) return;
        const norm = p.name.trim().toLowerCase();
        if (!knownNames.has(norm)) {
          knownNames.add(norm);
          list.push(p);
        }
      });
    }

    // Complement with regional catalog items
    REGIONAL_MARKET_CROPS.forEach((r) => {
      const norm = r.name.trim().toLowerCase();
      if (!knownNames.has(norm)) {
        knownNames.add(norm);
        list.push(r);
      }
    });

    return list;
  }, [produceList]);

  // Categories list
  const categories = useMemo(() => {
    const set = new Set<string>(['All']);
    allAvailableCrops.forEach((c) => {
      if (c.category) set.add(c.category);
    });
    return Array.from(set);
  }, [allAvailableCrops]);

  // Filtered crops for display
  const filteredProduce = useMemo(() => {
    return allAvailableCrops
      .filter((item) => {
        if (!item) return false;

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = (item.name || '').toLowerCase().includes(q);
          const matchVar = (item.variety || '').toLowerCase().includes(q);
          const matchCat = (item.category || '').toLowerCase().includes(q);
          if (!matchName && !matchVar && !matchCat) return false;
        }

        // Category filter
        if (selectedCategory !== 'All' && item.category !== selectedCategory) {
          return false;
        }

        // Distance filter
        if (maxDistance < 100) {
          const dist = typeof item.distanceKm === 'number' ? item.distanceKm : parseFloat(item.distanceKm as any) || 0;
          if (dist > maxDistance) return false;
        }

        return true;
      })
      .sort((a, b) => {
        const priceA = typeof a.pricePerUnit === 'number' ? a.pricePerUnit : parseFloat(a.pricePerUnit as any) || 0;
        const priceB = typeof b.pricePerUnit === 'number' ? b.pricePerUnit : parseFloat(b.pricePerUnit as any) || 0;
        if (sortBy === 'price_low') return priceA - priceB;

        const distA = typeof a.distanceKm === 'number' ? a.distanceKm : parseFloat(a.distanceKm as any) || 0;
        const distB = typeof b.distanceKm === 'number' ? b.distanceKm : parseFloat(b.distanceKm as any) || 0;
        if (sortBy === 'distance') return distA - distB;

        return 0;
      });
  }, [allAvailableCrops, searchQuery, selectedCategory, maxDistance, sortBy]);

  // Quick submit custom vegetable request
  const handleAddCustomRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customVegName.trim()) return;

    const pseudoItem: any = {
      id: `custom-veg-${Date.now()}`,
      name: customVegName.trim(),
      pricePerUnit: 50,
      unit: customVegUnit,
      stockQuantity: 9999,
      harvestStatus: 'Fresh Picked on Order',
      harvestDate: 'Harvested on request',
      imageUrl: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
      isOrganic: false,
      description: customVegNotes || `Custom requested vegetable: ${customVegName.trim()}`,
      location: 'Negros Oriental',
      distanceKm: 3.5,
      farmerId: 'farmer-pool',
      farmerName: 'To be sourced from local farmer',
      farmName: 'Registered Local Farmer',
    };

    onAddToCart(pseudoItem, e as any);
    setCustomVegName('');
    setCustomVegQty(5);
    setCustomVegNotes('');
    setShowCustomModal(false);
  };

  return (
    <div className="flex flex-col space-y-4 p-3.5 pb-20 w-full relative">
      {/* Buyer-Led Workflow Hero Banner */}
      <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-emerald-900 text-white rounded-3xl p-4 shadow-sm space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div className="space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-700/80 text-emerald-200 px-2 py-0.5 rounded-full inline-block">
              Buyer-Led Direct Sourcing
            </span>
            <h2 className="text-base font-extrabold text-white font-display">
              Request Any Vegetables to Buy
            </h2>
            <p className="text-xs text-emerald-100/90 leading-relaxed max-w-sm">
              Submit the specific vegetables and quantities you need. The Admin reviews your request, sources them fresh from local farmers, and delivers directly to you!
            </p>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center text-emerald-200 flex-shrink-0">
            <ClipboardList className="w-5 h-5" />
          </div>
        </div>

        {/* 4-Step Flow Indicator */}
        <div className="grid grid-cols-4 gap-1 pt-2 border-t border-emerald-700/70 text-[9px] text-center font-bold">
          <div className="bg-emerald-600 text-white p-1 rounded-lg">
            1. You Request
          </div>
          <div className="bg-emerald-950/60 text-emerald-200 p-1 rounded-lg">
            2. Admin Reviews
          </div>
          <div className="bg-emerald-950/60 text-emerald-200 p-1 rounded-lg">
            3. Farm Sourcing
          </div>
          <div className="bg-emerald-950/60 text-emerald-200 p-1 rounded-lg">
            4. Fulfilled
          </div>
        </div>

        {/* Primary Action Button: Custom Request */}
        <button
          onClick={() => setShowCustomModal(true)}
          className="w-full py-2.5 px-3 bg-white hover:bg-emerald-50 text-emerald-950 font-extrabold text-xs rounded-xl shadow-xs transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4 text-emerald-700 stroke-[3]" />
          <span>+ Create Custom Vegetable Purchase Request</span>
        </button>
      </div>

      {/* Search and Filter Row */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-emerald-700/60 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="input-market-search"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tomatoes, ampalaya, carrots, eggplant..."
            className="w-full min-h-[46px] bg-white border border-emerald-200/90 rounded-2xl pl-10 pr-9 py-2.5 text-xs text-emerald-950 placeholder-emerald-800/40 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 shadow-xs transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700 text-sm p-1 cursor-pointer font-bold"
            >
              ✕
            </button>
          )}
        </div>

        <button
          id="btn-toggle-filters"
          onClick={() => setShowFilterDrawer(!showFilterDrawer)}
          className={`min-h-[46px] min-w-[46px] p-2.5 rounded-2xl border text-xs flex items-center justify-center gap-1 transition-all active:scale-95 shadow-xs cursor-pointer ${
            showFilterDrawer || maxDistance < 100 || selectedCategory !== 'All'
              ? 'bg-emerald-700 text-white border-emerald-700 font-bold'
              : 'bg-white text-emerald-900 border-emerald-200 hover:bg-emerald-50'
          }`}
          title="Filter and Sort options"
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`min-h-[34px] px-3 py-1.5 rounded-full font-bold whitespace-nowrap transition-all cursor-pointer text-xs ${
              selectedCategory === cat
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-white text-emerald-900 border border-emerald-200/80 hover:bg-emerald-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Expandable Filter Panel */}
      {showFilterDrawer && (
        <div className="bg-white border border-emerald-200/90 rounded-2xl p-4 space-y-3 shadow-sm animate-in fade-in duration-150">
          <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
            <span>Filter Sourcing Options</span>
            <button
              onClick={() => {
                setMaxDistance(100);
                setSelectedCategory('All');
                setSortBy('freshness');
              }}
              className="text-[11px] text-emerald-700 font-semibold hover:underline cursor-pointer"
            >
              Reset All
            </button>
          </div>

          {/* Distance Slider */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between text-xs text-emerald-900">
              <span className="flex items-center gap-1 font-semibold">
                <MapPin className="w-3.5 h-3.5 text-emerald-600" /> Max Farm Distance
              </span>
              <span className="font-bold text-emerald-950 bg-emerald-100 px-2 py-0.5 rounded-full text-[11px]">
                {maxDistance >= 100 ? 'All Negros Oriental' : `${maxDistance} km`}
              </span>
            </div>
            <input
              type="range"
              min="5"
              max="100"
              step="5"
              value={maxDistance}
              onChange={(e) => setMaxDistance(Number(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer h-2 bg-emerald-100 rounded-lg"
            />
          </div>

          {/* Sort By */}
          <div className="flex items-center gap-2 text-xs text-emerald-900 pt-1">
            <ArrowUpDown className="w-3.5 h-3.5 text-emerald-600" />
            <span className="font-semibold text-[11px]">Sort:</span>
            <div className="flex gap-1.5">
              {(['freshness', 'price_low', 'distance'] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setSortBy(s)}
                  className={`min-h-[34px] px-2.5 py-1 rounded-xl text-[11px] font-bold cursor-pointer transition-all ${
                    sortBy === s
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-emerald-50 text-emerald-800 border border-emerald-200/70 hover:bg-emerald-100'
                  }`}
                >
                  {s === 'freshness' ? 'Standard' : s === 'price_low' ? 'Price: Low' : 'Distance'}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Produce Results Header */}
      <div className="flex items-center justify-between text-xs text-emerald-900 pt-1 px-1">
        <span>
          Available for Sourcing: <strong className="text-emerald-950 font-bold">{filteredProduce.length}</strong> vegetables
        </span>
        <span className="text-[11px] text-emerald-700 font-bold bg-emerald-100 px-2 py-0.5 rounded-full">
          Click "Request" to add to your order
        </span>
      </div>

      {/* Produce Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        {filteredProduce.map((produce) => (
          <ProduceCard
            key={produce.id}
            produce={produce}
            onSelect={onSelectProduce}
            onAddToCart={onAddToCart}
            isInCart={cartItemIds.has(produce.id)}
            isBuyer={isBuyer}
          />
        ))}
      </div>

      {/* Sticky Floating Request Basket Button */}
      {cartCount > 0 && onOpenCart && (
        <div className="fixed bottom-20 left-0 right-0 max-w-md mx-auto px-4 z-30 pointer-events-none">
          <button
            onClick={onOpenCart}
            className="pointer-events-auto w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-extrabold text-sm shadow-xl flex items-center justify-between transition-all active:scale-95 cursor-pointer border border-emerald-400"
          >
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-white text-emerald-800 text-xs font-black flex items-center justify-center">
                {cartCount}
              </span>
              <span>Purchase Request Basket</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-xs text-emerald-100 font-bold">Review & Send (Step 1)</span>
              <ArrowRight className="w-4 h-4 stroke-[3]" />
            </div>
          </button>
        </div>
      )}

      {/* Custom Vegetable Request Modal */}
      {showCustomModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl max-w-sm w-full p-4 space-y-3.5 shadow-2xl border border-emerald-200">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-xs text-neutral-900">Custom Purchase Request</h3>
                  <p className="text-[10px] text-neutral-500">Specify any vegetable & quantity you want</p>
                </div>
              </div>
              <button
                onClick={() => setShowCustomModal(false)}
                className="text-neutral-400 hover:text-neutral-700 font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddCustomRequest} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-neutral-700">Vegetable Name / Type</label>
                <input
                  type="text"
                  required
                  value={customVegName}
                  onChange={(e) => setCustomVegName(e.target.value)}
                  placeholder="e.g. Native Tomatoes, Sweet Potatoes, Kangkong"
                  className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2 text-xs text-neutral-900 font-medium focus:outline-none focus:border-emerald-600 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-neutral-700">Quantity Desired</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={customVegQty}
                    onChange={(e) => setCustomVegQty(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2 text-xs text-neutral-900 font-bold focus:outline-none focus:border-emerald-600 focus:bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-neutral-700">Unit</label>
                  <select
                    value={customVegUnit}
                    onChange={(e) => setCustomVegUnit(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2 text-xs text-neutral-900 font-bold focus:outline-none focus:border-emerald-600 focus:bg-white"
                  >
                    <option value="kg">kg (Kilogram)</option>
                    <option value="bundle">bundle (Tali)</option>
                    <option value="tray">tray (Plato)</option>
                    <option value="sack">sack (Sako)</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-neutral-700">Notes / Quality Requirements</label>
                <textarea
                  rows={2}
                  value={customVegNotes}
                  onChange={(e) => setCustomVegNotes(e.target.value)}
                  placeholder="e.g. Fresh green color, needed for restaurant catering on Friday"
                  className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2 text-xs text-neutral-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCustomModal(false)}
                  className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-xl shadow-xs cursor-pointer active:scale-95 transition-all"
                >
                  + Add to Purchase Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
