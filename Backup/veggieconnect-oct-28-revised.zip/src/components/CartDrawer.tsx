import React, { useState, useEffect } from 'react';
import {
  ClipboardList,
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  Store,
  Truck,
  ShieldCheck,
  CheckCircle2,
  MapPin,
  Calendar,
  User,
  Phone,
  AlertCircle,
  FileText,
  Sparkles,
  HelpCircle,
} from 'lucide-react';
import { CartItem, Order, OrderItem, UserProfile } from '../types';
import { DA_DAILY_PRICES } from '../data/daPricesData';

interface CartDrawerProps {
  cart: CartItem[];
  currentUser?: UserProfile | null;
  onUpdateQuantity: (produceId: string, quantity: number) => void;
  onRemoveItem: (produceId: string) => void;
  onClearCart: () => void;
  onOrderPlaced: (order: Order) => void;
  onClose: () => void;
}

const COMMON_VEGGIES = [
  { name: 'Tomato (Kamatis)', defaultPrice: 55, unit: 'kg' },
  { name: 'Ampalaya (Bitter Gourd)', defaultPrice: 80, unit: 'kg' },
  { name: 'Eggplant (Talong)', defaultPrice: 60, unit: 'kg' },
  { name: 'Cabbage (Repolyo)', defaultPrice: 75, unit: 'kg' },
  { name: 'Carrots', defaultPrice: 70, unit: 'kg' },
  { name: 'Bell Pepper (Atsal)', defaultPrice: 120, unit: 'kg' },
  { name: 'Red Onion (Sibuyas Pula)', defaultPrice: 140, unit: 'kg' },
  { name: 'Garlic Native (Bawang)', defaultPrice: 180, unit: 'kg' },
  { name: 'Ginger (Luya)', defaultPrice: 110, unit: 'kg' },
  { name: 'Chili Labuyo (Siling Labuyo)', defaultPrice: 240, unit: 'kg' },
  { name: 'Squash (Kalabasa)', defaultPrice: 45, unit: 'kg' },
  { name: 'Pechay / Bok Choy', defaultPrice: 40, unit: 'bundle' },
];

export const CartDrawer: React.FC<CartDrawerProps> = ({
  cart,
  currentUser,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOrderPlaced,
  onClose,
}) => {
  const [buyerName, setBuyerName] = useState(currentUser?.name || '');
  const [buyerPhone, setBuyerPhone] = useState(currentUser?.phone || '');
  const [deliveryType, setDeliveryType] = useState<'direct_delivery' | 'farm_pickup'>('direct_delivery');
  const [deliveryAddress, setDeliveryAddress] = useState(
    currentUser?.location || 'Dumaguete City Proper, Negros Oriental'
  );
  const [pickupSlot, setPickupSlot] = useState('Tomorrow Morning (08:00 AM - 11:00 AM)');
  const [requestNotes, setRequestNotes] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Custom inline item addition state
  const [showAddCustom, setShowAddCustom] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customQty, setCustomQty] = useState(5);
  const [customUnit, setCustomUnit] = useState('kg');
  const [customEstPrice, setCustomEstPrice] = useState(50);

  // Sync with current user changes
  useEffect(() => {
    if (currentUser) {
      if (currentUser.name && !buyerName) setBuyerName(currentUser.name);
      if (currentUser.phone && !buyerPhone) setBuyerPhone(currentUser.phone);
      if (currentUser.location && (!deliveryAddress || deliveryAddress.includes('Dumaguete City Proper'))) {
        setDeliveryAddress(currentUser.location);
      }
    }
  }, [currentUser]);

  // Estimated Subtotal calculation
  const subtotal = cart.reduce((sum, item) => {
    const unitPrice = item.produce.pricePerUnit || 50;
    return sum + unitPrice * item.quantity;
  }, 0);

  const deliveryFee = deliveryType === 'direct_delivery' ? 50 : 0;
  const totalAmount = subtotal + deliveryFee;

  // Add custom vegetable to request
  const handleAddCustomVegetable = () => {
    if (!customName.trim()) {
      setErrorMessage('Please enter the name of the vegetable you want to request.');
      return;
    }
    const pseudoItem: any = {
      id: `custom-req-${Date.now()}`,
      name: customName.trim(),
      pricePerUnit: customEstPrice > 0 ? customEstPrice : 50,
      unit: customUnit || 'kg',
      stockQuantity: 9999,
      harvestStatus: 'Fresh Picked on Order',
      harvestDate: 'Fresh harvest on request',
      imageUrl: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
      isOrganic: false,
      description: `Custom requested vegetable: ${customName.trim()}`,
      location: 'Negros Oriental Local Growers',
      distanceKm: 3.5,
      farmerId: 'farmer-pool',
      farmerName: 'To be sourced by Admin from registered farmers',
      farmName: 'Local Farmer Partner',
    };
    onUpdateQuantity(pseudoItem.id, customQty);
    // Push into cart directly via dispatch/custom logic
    cart.push({ produce: pseudoItem, quantity: customQty });
    setCustomName('');
    setCustomQty(5);
    setShowAddCustom(false);
    setErrorMessage(null);
  };

  const handleCheckout = () => {
    if (cart.length === 0) {
      setErrorMessage('Please add at least one vegetable and quantity to your purchase request.');
      return;
    }
    setErrorMessage(null);

    const trimmedName = buyerName.trim();
    const trimmedPhone = buyerPhone.trim();
    const trimmedAddress = deliveryAddress.trim();

    if (!trimmedName) {
      setErrorMessage('Please enter your Name or Business Name so Admin knows who requested this order.');
      return;
    }

    if (!trimmedPhone) {
      setErrorMessage('Please enter your Mobile / GCash Number for order verification and updates.');
      return;
    }

    if (deliveryType === 'direct_delivery' && !trimmedAddress) {
      setErrorMessage('Please enter your Delivery Address in Dumaguete / Negros Oriental.');
      return;
    }

    setIsSubmitting(true);

    const orderItems: OrderItem[] = cart.map((item) => ({
      produceId: item.produce.id,
      produceName: item.produce.name,
      imageUrl: item.produce.imageUrl,
      unitPrice: item.produce.pricePerUnit,
      pricePerUnit: item.produce.pricePerUnit,
      unit: item.produce.unit || 'kg',
      quantity: item.quantity,
      farmName: item.produce.farmName || 'To be sourced from local farmer',
      farmerId: item.produce.farmerId || 'pending_farmer_match',
      farmerName: item.produce.farmerName || 'To be sourced by Admin',
    }));

    const reqId = `REQ-${Date.now().toString().slice(-4)}`;

    const newOrder: Order = {
      id: reqId,
      buyerId: currentUser?.id || `buyer-${Date.now()}`,
      buyerName: trimmedName,
      buyerPhone: trimmedPhone,
      farmerId: 'pending_admin_sourcing',
      farmName: 'Sourced from local farmer',
      deliveryType,
      deliveryAddress: deliveryType === 'direct_delivery' ? trimmedAddress : 'VeggieConnect Central Depot (Rizal Blvd)',
      pickupSlot: pickupSlot.trim() || 'Flexible / As soon as sourced',
      items: orderItems,
      subtotal,
      deliveryFee,
      totalAmount,
      paymentMethod: 'Cash on Delivery / Pickup',
      status: 'pending', // Step 1: Buyer Request submitted
      requestStep: 1, // Step 1
      isBuyerRequest: true,
      notes: requestNotes.trim() ? requestNotes.trim() : `Buyer request for ${orderItems.map((i) => `${i.quantity} ${i.unit} ${i.produceName}`).join(', ')}`,
      createdAt: new Date().toISOString(),
    };

    setTimeout(() => {
      setIsSubmitting(false);
      onOrderPlaced(newOrder);
      onClearCart();
      onClose();
    }, 450);
  };

  return (
    <div className="flex flex-col min-h-full bg-emerald-50/40 p-3.5 relative">
      {/* Title Header */}
      <div className="flex items-center justify-between border-b border-emerald-200/80 pb-3 mb-3.5 flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-800">
            <ClipboardList className="w-4 h-4 text-emerald-700" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-emerald-950 font-display">
              Purchase Request to Admin
            </h2>
            <p className="text-[11px] text-emerald-700 font-semibold">
              Step 1 of 4 • Buyer Request Submission
            </p>
          </div>
        </div>
        {cart.length > 0 && (
          <button
            id="btn-clear-cart"
            onClick={onClearCart}
            className="min-h-[36px] px-2.5 py-1 text-xs text-neutral-500 hover:text-red-600 transition-colors flex items-center gap-1 font-semibold cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" /> Clear All
          </button>
        )}
      </div>

      {/* 4-Step Workflow Roadmap Pill */}
      <div className="bg-white border border-emerald-200 rounded-2xl p-3 mb-3 shadow-xs space-y-2">
        <div className="flex items-center justify-between text-[11px] font-extrabold text-emerald-950">
          <span className="flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            Buyer-Led Sourcing Process
          </span>
          <span className="text-[10px] bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded-full font-bold">
            Step 1 Active
          </span>
        </div>
        <div className="grid grid-cols-4 gap-1 text-[9px] text-center font-bold">
          <div className="bg-emerald-600 text-white p-1.5 rounded-xl shadow-2xs">
            1. Submit Request
          </div>
          <div className="bg-neutral-100 text-neutral-600 p-1.5 rounded-xl border border-neutral-200">
            2. Admin Review
          </div>
          <div className="bg-neutral-100 text-neutral-600 p-1.5 rounded-xl border border-neutral-200">
            3. Farm Sourcing
          </div>
          <div className="bg-neutral-100 text-neutral-600 p-1.5 rounded-xl border border-neutral-200">
            4. Fulfillment
          </div>
        </div>
      </div>

      {cart.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center p-8 space-y-3.5 my-auto bg-white border border-emerald-100 rounded-3xl shadow-xs">
          <div className="w-16 h-16 rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center text-3xl">
            📋
          </div>
          <h3 className="text-base font-bold text-emerald-950 font-display">No Vegetables Requested Yet</h3>
          <p className="text-xs text-neutral-600 max-w-xs leading-relaxed">
            Specify the exact vegetables and quantities you want to buy from local farmers. The Admin will review and source them for you!
          </p>
          <div className="flex flex-col gap-2 w-full max-w-xs">
            <button
              onClick={() => setShowAddCustom(true)}
              className="w-full min-h-[44px] px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition-colors shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Add Vegetables to Request</span>
            </button>
            <button
              onClick={onClose}
              className="w-full min-h-[44px] px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 font-bold rounded-xl text-xs transition-colors cursor-pointer"
            >
              Browse Vegetable Catalog
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-col space-y-3.5 pb-4 flex-1">
          {/* Requested Items List */}
          <div className="bg-white border border-emerald-200/85 rounded-2xl p-3.5 space-y-3 shadow-xs">
            <div className="flex items-center justify-between text-xs border-b border-emerald-100 pb-2">
              <div className="flex items-center gap-1.5 font-extrabold text-emerald-900">
                <ClipboardList className="w-4 h-4 text-emerald-700" />
                <span>Requested Vegetables & Quantities ({cart.length})</span>
              </div>
              <button
                onClick={() => setShowAddCustom(true)}
                className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Another</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {cart.map(({ produce, quantity }) => {
                const itemUnitPrice = produce.pricePerUnit || 50;
                const lineTotal = (itemUnitPrice * quantity).toFixed(2);

                return (
                  <div
                    key={produce.id}
                    className="flex items-center justify-between gap-3 text-xs bg-emerald-50/50 p-2.5 rounded-xl border border-emerald-200/70"
                  >
                    <img
                      src={produce.imageUrl || 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80'}
                      alt={produce.name}
                      className="w-12 h-12 rounded-xl object-cover bg-emerald-100 flex-shrink-0"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-emerald-950 truncate text-xs">{produce.name}</h4>
                      <div className="text-[11px] text-neutral-500 font-medium mt-0.5">
                        Est. ₱{itemUnitPrice.toFixed(2)} / {produce.unit || 'kg'}
                      </div>
                    </div>

                    {/* Quantity Stepper */}
                    <div className="flex items-center gap-1 bg-white border border-emerald-200 rounded-xl p-0.5 shadow-2xs">
                      <button
                        onClick={() => {
                          if (quantity <= 1) {
                            onRemoveItem(produce.id);
                          } else {
                            onUpdateQuantity(produce.id, quantity - 1);
                          }
                        }}
                        className="w-7 h-7 rounded-lg flex items-center justify-center bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-bold cursor-pointer"
                        title="Decrease quantity"
                      >
                        <Minus className="w-3.5 h-3.5 stroke-[2.5]" />
                      </button>
                      <span className="w-8 text-center font-extrabold text-emerald-950 text-xs">
                        {quantity} {produce.unit || 'kg'}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(produce.id, quantity + 1)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-bold cursor-pointer"
                        title="Increase quantity"
                      >
                        <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                      </button>
                    </div>

                    <div className="w-14 text-right font-black text-emerald-900 text-xs">
                      ₱{lineTotal}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Add Custom Vegetable Drawer / Inline Form */}
          {showAddCustom && (
            <div className="bg-white border-2 border-emerald-500/80 rounded-2xl p-3.5 space-y-3 shadow-md animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs text-neutral-900 flex items-center gap-1.5">
                  <Plus className="w-4 h-4 text-emerald-600" />
                  Add Specific Vegetable to Request
                </h4>
                <button
                  onClick={() => setShowAddCustom(false)}
                  className="text-xs text-neutral-400 hover:text-neutral-700 font-bold p-1 cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Quick Suggestions Chips */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-neutral-500 uppercase">Quick Select Popular Crops:</label>
                <div className="flex flex-wrap gap-1.5">
                  {COMMON_VEGGIES.map((v) => (
                    <button
                      key={v.name}
                      type="button"
                      onClick={() => {
                        setCustomName(v.name);
                        setCustomEstPrice(v.defaultPrice);
                        setCustomUnit(v.unit);
                      }}
                      className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 text-[10px] font-bold rounded-lg border border-emerald-200 transition-colors cursor-pointer"
                    >
                      {v.name} (₱{v.defaultPrice}/{v.unit})
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="col-span-2 space-y-1">
                  <label className="text-[11px] font-bold text-neutral-700">Vegetable Name / Variety</label>
                  <input
                    type="text"
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    placeholder="e.g. Native Tomatoes, Organic Carrots, Ampalaya"
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2 text-xs text-neutral-900 font-medium focus:outline-none focus:border-emerald-600 focus:bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-neutral-700">Quantity</label>
                  <input
                    type="number"
                    min="1"
                    value={customQty}
                    onChange={(e) => setCustomQty(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2 text-xs text-neutral-900 font-bold focus:outline-none focus:border-emerald-600 focus:bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-neutral-700">Unit</label>
                  <select
                    value={customUnit}
                    onChange={(e) => setCustomUnit(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2 text-xs text-neutral-900 font-bold focus:outline-none focus:border-emerald-600 focus:bg-white"
                  >
                    <option value="kg">kg (Kilogram)</option>
                    <option value="bundle">bundle (Tali)</option>
                    <option value="tray">tray (Plato)</option>
                    <option value="sack">sack (Sako)</option>
                  </select>
                </div>
              </div>

              <button
                type="button"
                onClick={handleAddCustomVegetable}
                className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer"
              >
                + Add to Request List
              </button>
            </div>
          )}

          {/* Fulfillment & Delivery Option */}
          <div className="bg-white border border-emerald-200/85 rounded-2xl p-3.5 space-y-3 shadow-xs">
            <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wider flex items-center gap-1.5">
              <Truck className="w-4 h-4 text-emerald-700" />
              1. Delivery / Pickup Preference
            </h4>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setDeliveryType('direct_delivery')}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                  deliveryType === 'direct_delivery'
                    ? 'bg-emerald-50 border-emerald-600 ring-1 ring-emerald-600'
                    : 'bg-white border-neutral-200 hover:bg-neutral-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-neutral-900">Direct Delivery</span>
                  <span className="text-[10px] font-bold text-emerald-700">₱50 Haul</span>
                </div>
                <p className="text-[10px] text-neutral-500">Admin delivers directly to your address once sourced.</p>
              </button>

              <button
                type="button"
                onClick={() => setDeliveryType('farm_pickup')}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                  deliveryType === 'farm_pickup'
                    ? 'bg-emerald-50 border-emerald-600 ring-1 ring-emerald-600'
                    : 'bg-white border-neutral-200 hover:bg-neutral-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-neutral-900">Central Depot</span>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 rounded">FREE</span>
                </div>
                <p className="text-[10px] text-neutral-500">Pickup at Dumaguete Central Supermarket Depot.</p>
              </button>
            </div>

            {deliveryType === 'direct_delivery' && (
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-neutral-700 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" /> Delivery Address in Dumaguete / Negros
                </label>
                <input
                  type="text"
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  placeholder="Street address, barangay, landmark (e.g. Piapi, Bantayan, Mangnao)"
                  className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2 text-xs text-neutral-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
                />
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-neutral-700 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" /> Preferred Timing / Schedule
              </label>
              <input
                type="text"
                value={pickupSlot}
                onChange={(e) => setPickupSlot(e.target.value)}
                placeholder="e.g. Tomorrow 9:00 AM, Friday morning, or ASAP"
                className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2 text-xs text-neutral-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
              />
            </div>
          </div>

          {/* Buyer Details */}
          <div className="bg-white border border-emerald-200/85 rounded-2xl p-3.5 space-y-3 shadow-xs">
            <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wider">
              2. Buyer Contact Information
            </h4>
            <div className="grid grid-cols-1 gap-2.5">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-emerald-900 flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-emerald-700" /> Full Name / Business Name
                </label>
                <input
                  type="text"
                  value={buyerName}
                  onChange={(e) => setBuyerName(e.target.value)}
                  placeholder="Enter your name (e.g. Maria Santos)"
                  className="w-full min-h-[44px] bg-emerald-50/30 border border-emerald-200 rounded-xl px-3 py-2 text-xs text-emerald-950 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-emerald-900 flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-emerald-700" /> Mobile / GCash Number
                </label>
                <input
                  type="tel"
                  value={buyerPhone}
                  onChange={(e) => setBuyerPhone(e.target.value)}
                  placeholder="0917 123 4567"
                  className="w-full min-h-[44px] bg-emerald-50/30 border border-emerald-200 rounded-xl px-3 py-2 text-xs text-emerald-950 focus:outline-none focus:border-emerald-600 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-emerald-900 flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 text-emerald-700" /> Special Sourcing Notes for Admin
                </label>
                <textarea
                  rows={2}
                  value={requestNotes}
                  onChange={(e) => setRequestNotes(e.target.value)}
                  placeholder="e.g. Firm vegetables preferred for restaurant use, need clean harvest, target price range..."
                  className="w-full bg-emerald-50/30 border border-emerald-200 rounded-xl px-3 py-2 text-xs text-emerald-950 focus:outline-none focus:border-emerald-600"
                />
              </div>
            </div>
          </div>

          {/* Cost Estimate Breakdown */}
          <div className="bg-white border border-emerald-200/85 rounded-2xl p-3.5 space-y-2 text-xs shadow-xs">
            <div className="flex justify-between text-neutral-600">
              <span>Estimated Produce Cost:</span>
              <span className="text-emerald-950 font-bold">₱{subtotal.toFixed(2)}</span>
            </div>
            {deliveryFee > 0 && (
              <div className="flex justify-between text-neutral-600">
                <span>Direct Delivery Haul Fee:</span>
                <span className="text-emerald-950 font-bold">₱{deliveryFee.toFixed(2)}</span>
              </div>
            )}
            <div className="border-t border-emerald-100 pt-2 flex justify-between text-sm font-black text-emerald-950">
              <span>Estimated Total Amount:</span>
              <span className="text-emerald-700 font-black">₱{totalAmount.toFixed(2)}</span>
            </div>
            <p className="text-[10px] text-neutral-500 font-medium pt-1 border-t border-dashed border-emerald-100">
              💡 <strong>How it works:</strong> The Admin reviews your request, sources the exact vegetables from local registered farmers in Negros Oriental, and fulfills your order. Payment is settled upon delivery/pickup.
            </p>
          </div>

          {/* Error Message if any */}
          {errorMessage && (
            <div className="bg-red-50 border border-red-200 rounded-2xl p-3 text-xs text-red-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Sticky Bottom Submit Bar */}
          <div className="sticky bottom-0 -mx-3.5 -mb-3.5 mt-2 bg-white/95 backdrop-blur-md border-t border-emerald-200/90 p-4 z-30 shadow-[0_-8px_24px_rgba(0,0,0,0.06)]">
            <div className="flex items-center justify-between gap-3 mb-2.5">
              <div>
                <span className="text-[10px] uppercase font-bold text-neutral-500 block tracking-wider">
                  Est. Order Total
                </span>
                <div className="text-xl font-black text-emerald-950">
                  ₱{totalAmount.toFixed(2)}
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-neutral-500 block">Workflow</span>
                <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                  Step 1: Send Request to Admin
                </span>
              </div>
            </div>

            <button
              id="btn-submit-buyer-request"
              onClick={handleCheckout}
              disabled={isSubmitting || cart.length === 0}
              className="w-full min-h-[48px] py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-extrabold text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-sm disabled:opacity-50 cursor-pointer"
            >
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Submitting Request to Admin...
                </span>
              ) : (
                <>
                  <span>Submit Purchase Request to Admin (Step 1)</span>
                  <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
